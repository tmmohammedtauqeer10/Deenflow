import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { localUsers } from "@db/schema";
import { eq, or } from "drizzle-orm";
import { hashPassword, comparePassword, signLocalToken } from "./local-auth-utils";

export const localAuthRouter = createRouter({
  register: publicQuery
    .input(
      z.object({
        username: z.string().min(3).max(50),
        email: z.string().email(),
        password: z.string().min(6),
        displayName: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Check if username or email already exists
      const existing = await db.query.localUsers.findFirst({
        where: or(
          eq(localUsers.username, input.username),
          eq(localUsers.email, input.email)
        ),
      });

      if (existing) {
        throw new TRPCError({
          code: "CONFLICT",
          message:
            existing.username === input.username
              ? "Username already taken"
              : "Email already registered",
        });
      }

      const passwordHash = await hashPassword(input.password);

      const result = await db.insert(localUsers).values({
        username: input.username,
        email: input.email,
        displayName: input.displayName || input.username,
        passwordHash,
      });

      const userId = Number(result[0].insertId);
      const token = signLocalToken(userId);

      return { token, userId };
    }),

  login: publicQuery
    .input(
      z.object({
        username: z.string(),
        password: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const user = await db.query.localUsers.findFirst({
        where: eq(localUsers.username, input.username),
      });

      if (!user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid username or password",
        });
      }

      const valid = await comparePassword(input.password, user.passwordHash);
      if (!valid) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid username or password",
        });
      }

      const token = signLocalToken(user.id);
      return { token, userId: user.id };
    }),

  me: publicQuery.query(async ({ ctx }) => {
    const localAuthToken = ctx.req.headers.get("x-local-auth-token");
    if (!localAuthToken) return null;

    const { verifyLocalToken } = await import("./local-auth-utils");
    const user = await verifyLocalToken(localAuthToken);
    if (!user) return null;

    return {
      id: user.id,
      name: user.displayName || user.username,
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      role: user.role,
    };
  }),
});
