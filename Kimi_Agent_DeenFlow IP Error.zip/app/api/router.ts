import { authRouter } from "./auth-router";
import { localAuthRouter } from "./local-auth-router";
import { bookmarkRouter } from "./bookmark-router";
import { quizRouter } from "./quiz-router";
import { contactRouter } from "./contact-router";
import { chatRouter } from "./chat-router";
import { adminRouter } from "./admin-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  localAuth: localAuthRouter,
  bookmark: bookmarkRouter,
  quiz: quizRouter,
  contact: contactRouter,
  chat: chatRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
