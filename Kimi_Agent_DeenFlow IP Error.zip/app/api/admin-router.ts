import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users, localUsers, bookmarks, quizResults, contacts, chatMessages } from "@db/schema";
import { count } from "drizzle-orm";

export const adminRouter = createRouter({
  stats: adminQuery.query(async () => {
    const db = getDb();

    const [totalUsersResult] = await db.select({ value: count() }).from(users);
    const [totalLocalUsersResult] = await db.select({ value: count() }).from(localUsers);
    const [totalBookmarksResult] = await db.select({ value: count() }).from(bookmarks);
    const [totalQuizResult] = await db.select({ value: count() }).from(quizResults);
    const [totalContactsResult] = await db.select({ value: count() }).from(contacts);
    const [totalChatsResult] = await db.select({ value: count() }).from(chatMessages);

    return {
      totalUsers: totalUsersResult.value,
      totalLocalUsers: totalLocalUsersResult.value,
      totalBookmarks: totalBookmarksResult.value,
      totalQuizAttempts: totalQuizResult.value,
      totalContacts: totalContactsResult.value,
      totalChats: totalChatsResult.value,
    };
  }),

  users: adminQuery.query(async () => {
    const db = getDb();
    const oauthUsers = await db.query.users.findMany();
    const local = await db.query.localUsers.findMany();
    return {
      oauthUsers,
      localUsers: local.map((u) => ({
        id: u.id,
        username: u.username,
        email: u.email,
        displayName: u.displayName,
        role: u.role,
        createdAt: u.createdAt,
      })),
    };
  }),

  quizResults: adminQuery.query(async () => {
    const db = getDb();
    return db.query.quizResults.findMany();
  }),
});
