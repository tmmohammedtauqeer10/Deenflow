import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { bookmarks } from "@db/schema";
import { eq, and } from "drizzle-orm";

export const bookmarkRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const user = ctx.user!;

    if (user.authType === "oauth") {
      return db.query.bookmarks.findMany({
        where: eq(bookmarks.userId, user.id),
        orderBy: (b, { desc }) => [desc(b.createdAt)],
      });
    } else {
      return db.query.bookmarks.findMany({
        where: eq(bookmarks.localUserId, user.id),
        orderBy: (b, { desc }) => [desc(b.createdAt)],
      });
    }
  }),

  add: authedQuery
    .input(
      z.object({
        bookId: z.string(),
        bookTitle: z.string(),
        bookAuthor: z.string().optional(),
        bookCategory: z.string().optional(),
        pdfUrl: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const user = ctx.user!;

      const values: Record<string, unknown> = {
        bookId: input.bookId,
        bookTitle: input.bookTitle,
        bookAuthor: input.bookAuthor,
        bookCategory: input.bookCategory,
        pdfUrl: input.pdfUrl,
      };

      if (user.authType === "oauth") {
        values.userId = user.id;
      } else {
        values.localUserId = user.id;
      }

      const result = await db.insert(bookmarks).values(values as typeof bookmarks.$inferInsert);
      return { id: Number(result[0].insertId) };
    }),

  remove: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const user = ctx.user!;

      if (user.authType === "oauth") {
        await db
          .delete(bookmarks)
          .where(and(eq(bookmarks.id, input.id), eq(bookmarks.userId, user.id)));
      } else {
        await db
          .delete(bookmarks)
          .where(and(eq(bookmarks.id, input.id), eq(bookmarks.localUserId, user.id)));
      }

      return { success: true };
    }),

  check: authedQuery
    .input(z.object({ bookId: z.string() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const user = ctx.user!;

      let bookmark;
      if (user.authType === "oauth") {
        bookmark = await db.query.bookmarks.findFirst({
          where: and(eq(bookmarks.userId, user.id), eq(bookmarks.bookId, input.bookId)),
        });
      } else {
        bookmark = await db.query.bookmarks.findFirst({
          where: and(eq(bookmarks.localUserId, user.id), eq(bookmarks.bookId, input.bookId)),
        });
      }

      return !!bookmark;
    }),
});
