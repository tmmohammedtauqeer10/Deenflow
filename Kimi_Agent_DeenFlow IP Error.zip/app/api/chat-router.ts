import { z } from "zod";
import { createRouter, authedQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { chatMessages } from "@db/schema";
import { eq, desc } from "drizzle-orm";

// ============================================================
// DEENFLOW ISLAMIC AI KNOWLEDGE BASE
// Comprehensive structured knowledge for AI responses
// Sources: Quran, Sahih Hadith (Bukhari, Muslim), Authentic Fiqh
// ============================================================

interface KnowledgeEntry {
  keywords: string[];
  title: string;
  answer: string;
  source: string;
  category: string;
}

const ISLAMIC_KNOWLEDGE: KnowledgeEntry[] = [
  // QURAN
  {
    keywords: ["quran", "qur'an", "holy book", "revelation", "wahy"],
    title: "What is the Quran?",
    answer: "The Quran (al-Qur'an) is the verbatim word of Allah (SWT), revealed to Prophet Muhammad (PBUH) through the Angel Jibreel (Gabriel) over a period of 23 years. It is the final and complete divine scripture, preserved in its original Arabic form without any alteration. The Quran consists of 114 Surahs (chapters) and approximately 6,236 verses. It covers all aspects of life — worship, morality, law, guidance, and stories of previous nations and prophets. Allah has promised to protect it: 'Indeed, it is We who sent down the Quran, and indeed, We will be its guardian.' (15:9)",
    source: "Quran 15:9, 2:185, 17:9",
    category: "quran",
  },
  {
    keywords: ["surah fatiha", "al-fatiha", "opening", "first surah", "sabab al-mathani"],
    title: "Surah Al-Fatiha — The Opening",
    answer: "Surah Al-Fatiha is the first Surah of the Quran and is considered the greatest Surah. It is also known as Umm al-Kitab (Mother of the Book), Al-Shifa (The Cure), and Asas al-Quran (Foundation of the Quran). It consists of 7 verses and is recited in every unit (Rak'ah) of every prayer — making it the most recited chapter. The Prophet (PBUH) said: 'By the One in Whose Hand is my soul, Allah has not revealed the like of it in the Torah, the Gospel, the Psalms, or the Quran.' (Tirmidhi). It is a conversation between the servant and Allah — praising Him, seeking His guidance, and asking for the straight path.",
    source: "Sahih Tirmidhi 3124, Sahih Muslim 394",
    category: "quran",
  },
  {
    keywords: ["surah ikhlas", "al-ikhlas", "sincerity", "qul huwallahu ahad", "tawhid", "oneness"],
    title: "Surah Al-Ikhlas — The Sincerity",
    answer: "Surah Al-Ikhlas (112) is equivalent to one-third of the Quran in reward. It consists of 4 verses that establish pure Tawhid (monotheism). The Prophet (PBUH) said: 'By the One in Whose Hand is my soul, it is equivalent to one-third of the Quran.' (Bukhari & Muslim). Reciting it sincerely wipes out minor sins. Its four verses declare: (1) Allah is One and Unique, (2) He is Eternal and Absolute, (3) He begets not, nor was He begotten, (4) There is none comparable to Him.",
    source: "Sahih al-Bukhari 5013, Sahih Muslim 811",
    category: "quran",
  },
  {
    keywords: ["surah kahf", "al-kahf", "cave", "friday", "dajjal", "protection"],
    title: "Surah Al-Kahf — The Cave",
    answer: "Surah Al-Kahf (18) contains 110 verses and is highly recommended to be recited every Friday. The Prophet (PBUH) said: 'Whoever reads Surah Al-Kahf on Friday, light will shine for him between the two Fridays.' (Nasa'i). It contains four great stories: (1) The People of the Cave (faith in youth), (2) The Two Men with Gardens (wealth and humility), (3) Musa and Khidr (knowledge and patience), (4) Dhul-Qarnayn (power and justice). It also provides protection against the Dajjal (Antichrist).",
    source: "Sunan al-Nasa'i, Sahih Muslim 809",
    category: "quran",
  },
  {
    keywords: ["surah yasin", "yaseen", "heart of quran"],
    title: "Surah Yasin — Heart of the Quran",
    answer: "Surah Yasin (36) is known as the 'Heart of the Quran.' The Prophet (PBUH) said: 'Indeed, everything has a heart, and the heart of the Quran is Yasin. Whoever recites Yasin, Allah will record for him a reward equal to that of reading the Quran ten times.' (Tirmidhi). It contains 83 verses focusing on: the reality of prophethood, resurrection and afterlife, signs of Allah's power in creation, and the fate of those who reject the truth. It is often recited for the sick and deceased.",
    source: "Sunan al-Tirmidhi 2887",
    category: "quran",
  },
  {
    keywords: ["surah mulk", "al-mulk", "dominion", "protection from grave", "tabarak"],
    title: "Surah Al-Mulk — The Dominion",
    answer: "Surah Al-Mulk (67), also known as Tabarak, consists of 30 verses. The Prophet (PBUH) said: 'There is a Surah in the Quran of thirty verses that will intercede for its reciter until he is forgiven — it is Tabarak Alladhi Biyadihil Mulk.' (Tirmidhi & Abu Dawud). Reciting it every night provides protection from the punishment of the grave. It powerfully describes Allah's complete dominion over the universe and challenges people to reflect on creation.",
    source: "Sunan al-Tirmidhi 2891, Sunan Abu Dawud 1400",
    category: "quran",
  },
  {
    keywords: ["ayatul kursi", "ayat al-kursi", "throne verse", "protection", "greatest verse"],
    title: "Ayat al-Kursi — The Throne Verse",
    answer: "Ayat al-Kursi (2:255) is the greatest verse of the Quran. The Prophet (PBUH) said: 'Whoever recites Ayat al-Kursi immediately after each prescribed prayer, there will be nothing standing between him and his entering Paradise except death.' (Nasa'i). Ubay ibn Ka'b (RA) asked: 'O Messenger of Allah, what is the greatest verse?' He replied: 'Ayat al-Kursi.' (Muslim). It describes Allah's absolute sovereignty, knowledge, and power. Reciting it before sleep provides protection through the night.",
    source: "Sahih Muslim 810, Sunan al-Nasa'i",
    category: "quran",
  },
  {
    keywords: ["last ten surah", "small surah", "muawwidhat", "qul surah", "short surah"],
    title: "Last Ten Surahs & Muawwidhat",
    answer: "The last ten Surahs of the Quran (from Al-Fil to An-Nas) are short but powerful. The last three — Al-Ikhlas (112), Al-Falaq (113), and An-Nas (114) — are called the Muawwidhat (Surahs of Refuge). The Prophet (PBUH) would recite them before sleeping and blow into his hands, wiping over his body. He said: 'There is no one who seeks refuge with anything like these.' (Tirmidhi). Al-Falaq protects from envy and evil of darkness, while An-Nas protects from the whispers of Shaytan. They are recited in the Witr prayer and after each obligatory prayer.",
    source: "Sahih Muslim 4069, Sunan al-Tirmidhi 3497",
    category: "quran",
  },
  {
    keywords: ["quran recitation", "tajweed", "rules", "proper reading", "madd", "ghunnah"],
    title: "Tajweed — Proper Quran Recitation",
    answer: "Tajweed (تجويد) means 'to make better' or 'to improve.' It is the set of rules governing the proper pronunciation of Quranic Arabic. Key rules include: (1) Makharij al-Huruf — correct articulation points for each letter, (2) Sifat al-Huruf — characteristics of letters (heavy/light, etc.), (3) Madd — elongation rules (2, 4, or 6 counts), (4) Ghunnah — nasalization, (5) Idgham — merging of letters, (6) Ikhfa — hiding of letters, (7) Qalqalah — echoing sound. The Prophet (PBUH) said: 'The one who is proficient in reciting the Quran will be with the honorable scribes (angels).' (Bukhari & Muslim).",
    source: "Sahih al-Bukhari 4937, Sahih Muslim 798",
    category: "quran",
  },
  // HADITH
  {
    keywords: ["hadith", "sunnah", "prophet tradition", "narration"],
    title: "What are Hadith?",
    answer: "Hadith (الحديث) are the sayings, actions, approvals, and descriptions of Prophet Muhammad (PBUH). Together with the Quran, they form the primary sources of Islamic law and guidance. Hadith consist of two parts: (1) Isnad (Sanad) — the chain of narrators, and (2) Matn — the actual text. The six major authentic collections are: Sahih al-Bukhari (7,563 hadiths), Sahih Muslim (3,032), Sunan Abu Dawud (3,998), Jami' al-Tirmidhi (3,956), Sunan al-Nasa'i, and Sunan Ibn Majah. The Prophet (PBUH) said: 'May Allah brighten the face of one who heard from us something and then conveyed it as he heard it.' (Tirmidhi).",
    source: "Sahih al-Bukhari, Sahih Muslim — Introduction",
    category: "hadith",
  },
  {
    keywords: ["sahih bukhari", "imam bukhari", "most authentic"],
    title: "Sahih al-Bukhari — The Most Authentic Book",
    answer: "Sahih al-Bukhari is the most authentic book after the Quran, compiled by Imam Muhammad ibn Ismail al-Bukhari (810-870 CE). He traveled across the Islamic world for 16 years, collecting 600,000 narrations, from which he selected approximately 7,563 authentic hadiths. His conditions for authenticity were the strictest in hadith science: every narrator in the chain had to be trustworthy (thiqah) with precise memory (dabt), and the chain had to be connected (ittisal). He prayed two Rak'ahs before including any hadith. The Prophet (PBUH) said about his ummah: 'A group of my ummah will continue to prevail on truth...' (Bukhari).",
    source: "Sahih al-Bukhari — Introduction, Fath al-Bari",
    category: "hadith",
  },
  {
    keywords: ["sahih muslim", "imam muslim", "second most authentic"],
    title: "Sahih Muslim — The Second Most Authentic",
    answer: "Sahih Muslim is the second most authentic book after Sahih al-Bukhari, compiled by Imam Muslim ibn al-Hajjaj al-Qushayri (821-875 CE). It contains approximately 3,032 hadiths (excluding repetitions). Imam Muslim's methodology focused on the precision of narrators and their reliability. Unlike Bukhari, he did not include the biographies of narrators in his work — focusing purely on the narrations themselves. Both Bukhari and Muslim are called the 'Two Sahihs' (as-Sahihayn) and are accepted by the entire Ummah as the most authentic collections.",
    source: "Sahih Muslim — Introduction",
    category: "hadith",
  },
  {
    keywords: ["40 hadith", "nawawi", "imam nawawi", "forty hadith"],
    title: "The 40 Hadith of Imam al-Nawawi",
    answer: "Imam al-Nawawi (631-676 AH) compiled 40 hadiths that cover the fundamental principles of Islam. He said: 'Everyone desiring the Hereafter should know these hadiths.' The collection includes foundational hadiths like: (1) 'Actions are judged by intentions' (Bukhari & Muslim), (2) 'Islam is built on five pillars' (Bukhari & Muslim), (3) 'Halal is clear and haram is clear' (Bukhari & Muslim), (4) 'Whoever innovates something in this matter of ours will have it rejected' (Bukhari & Muslim). These 40 hadiths are memorized and studied by students of knowledge worldwide.",
    source: "Imam al-Nawawi's Forty Hadith — Introduction",
    category: "hadith",
  },
  {
    keywords: ["intentions", "niyyah", "actions judged", "sincerity", "ikhlas"],
    title: "The Hadith of Intentions",
    answer: "The Prophet (PBUH) said: 'Actions are judged by intentions, and every person will get what he intended. So whoever emigrated for the sake of Allah and His Messenger, his emigration is for Allah and His Messenger. And whoever emigrated for worldly gain or to marry a woman, his emigration is for that which he emigrated.' (Bukhari & Muslim). This is the first hadith in Sahih al-Bukhari and Imam al-Nawawi's collection. It teaches that sincerity of intention transforms ordinary actions into acts of worship. Imam Ibn Rajab said: 'This hadith encompasses one-third of knowledge.'",
    source: "Sahih al-Bukhari 1, Sahih Muslim 1907",
    category: "hadith",
  },
  {
    keywords: ["seeking knowledge", "ilm", "learning", "knowledge obligation", "student"],
    title: "The Obligation of Seeking Knowledge",
    answer: "The Prophet (PBUH) said: 'Seeking knowledge is an obligation upon every Muslim.' (Ibn Majah). He also said: 'Whoever takes a path upon which to obtain knowledge, Allah makes the path to Paradise easy for him.' (Muslim). Islam encourages knowledge-seeking as a lifelong journey. The Quran repeatedly commands reflection, observation, and thinking: 'Say, Are those who know equal to those who do not know? Only they will remember who are people of understanding.' (39:9). The first word revealed in the Quran was 'Iqra' (Read!). Knowledge of Deen is the most virtuous form of knowledge.",
    source: "Sunan Ibn Majah 224, Sahih Muslim 2699",
    category: "hadith",
  },
  // FIQH
  {
    keywords: ["five pillars", "pillars of islam", "arkan", "fundamentals", "islam basics"],
    title: "The Five Pillars of Islam",
    answer: "The Five Pillars (Arkan al-Islam) are the foundation of a Muslim's life, mentioned in the famous hadith of Jibreel: (1) Shahada — Testimony of faith: 'There is no god but Allah, and Muhammad is His Messenger.' (2) Salah — Prayer: Five daily prayers at prescribed times. (3) Zakat — Obligatory charity: 2.5% of accumulated wealth given annually to the poor. (4) Sawm — Fasting: Abstaining from food, drink, and marital relations from dawn to sunset during Ramadan. (5) Hajj — Pilgrimage: Performing the pilgrimage to Makkah at least once in a lifetime if physically and financially able. The Prophet (PBUH) said: 'Islam is built on five...' (Bukhari & Muslim).",
    source: "Sahih al-Bukhari 8, Sahih Muslim 16",
    category: "fiqh",
  },
  {
    keywords: ["wudu", "ablution", "washing", "prayer preparation", "taharah", "purification"],
    title: "Wudu (Ablution) — Step by Step",
    answer: "Wudu is the ritual purification required before prayer. The Fard (obligatory) steps are: (1) Intention (Niyyah), (2) Washing the face once, (3) Washing hands up to elbows, (4) Wiping over the head, (5) Washing feet up to ankles. The Sunnah steps include: saying Bismillah, washing hands 3 times, rinsing mouth and nose 3 times, wiping ears, and washing each limb 3 times. The Prophet (PBUH) said: 'Whoever performs wudu perfectly and then says: Ashhadu an la ilaha illallahu wahdahu la sharika lahu... the eight gates of Paradise are opened for him and he may enter through whichever he wishes.' (Muslim). Things that break wudu include: passing wind, urination, deep sleep, and touching private parts.",
    source: "Sahih Muslim 234, Sahih al-Bukhari 159",
    category: "fiqh",
  },
  {
    keywords: ["salah", "prayer", "namaz", "how to pray", "prayer method"],
    title: "How to Perform Salah (Prayer)",
    answer: "Salah is the second pillar of Islam, performed five times daily: Fajr (2 Rak'ahs), Dhuhr (4), Asr (4), Maghrib (3), and Isha (4). Each Rak'ah consists of: (1) Standing (Qiyam) with Surah Fatiha + another Surah, (2) Bowing (Ruku') with Tasbih, (3) Standing up (Qawmah), (4) Prostration (Sujud) with Tasbih, (5) Sitting between prostrations (Jalsah), (6) Second prostration. After the final Rak'ah, sit for Tashahhud (Attahiyyat), then Darud (Salawat on the Prophet), then Dua, and finally Tasleem (Salam to both sides). The Prophet (PBUH) said: 'The difference between us and them (disbelievers) is prayer. Whoever abandons it has disbelieved.' (Muslim, Tirmidhi).",
    source: "Sahih al-Bukhari 8, Sahih Muslim 146",
    category: "fiqh",
  },
  {
    keywords: ["ramadan", "fasting", "sawm", "roza", "fast rules"],
    title: "Ramadan and Fasting (Sawm)",
    answer: "Ramadan is the 9th month of the Islamic lunar calendar when Muslims fast from dawn (Fajr) to sunset (Maghrib). Fasting means abstaining from food, drink, marital relations, and sinful speech/behavior. The Prophet (PBUH) said: 'When Ramadan enters, the gates of Paradise are opened, the gates of Hell are closed, and the devils are chained.' (Bukhari & Muslim). Fasting is obligatory for every adult Muslim (except those with valid excuses: illness, travel, pregnancy, breastfeeding, extreme old age). The night of Ramadan contains Laylat al-Qadr, which is 'better than a thousand months' (97:3). Taraweeh prayers are performed nightly in congregation.",
    source: "Sahih al-Bukhari 1899, Sahih Muslim 1079",
    category: "fiqh",
  },
  {
    keywords: ["zakat", "charity", "poor due", "2.5 percent", "wealth tax"],
    title: "Zakat — Obligatory Charity",
    answer: "Zakat is the third pillar of Islam, an obligatory annual charity of 2.5% of accumulated wealth (gold, silver, cash, trade goods) held for one lunar year above the Nisab threshold (approximately 85g of gold or 595g of silver). The Quran says: 'Take, [O Muhammad], from their wealth a charity by which you purify them and cause them increase...' (9:103). There are 8 categories of Zakat recipients mentioned in the Quran (9:60): the poor, the needy, Zakat administrators, those whose hearts are to be reconciled, freeing captives, the debt-ridden, in the cause of Allah, and the wayfarer. Zakat purifies wealth and the soul from greed and miserliness.",
    source: "Quran 9:60, 9:103, Sahih al-Bukhari 1403",
    category: "fiqh",
  },
  {
    keywords: ["hajj", "pilgrimage", "umrah", "mecca", "kaaba", "ihram"],
    title: "Hajj — The Pilgrimage",
    answer: "Hajj is the fifth pillar of Islam, obligatory once in a lifetime for every Muslim who is physically and financially able. It is performed in Dhul-Hijjah (12th Islamic month) at Makkah. The main rituals are: (1) Ihram — entering the sacred state with white garments, (2) Tawaf — circling the Kaaba 7 times, (3) Sa'i — walking between Safa and Marwah 7 times, (4) Standing at Arafah (Wuquf) — the most essential ritual on the 9th of Dhul-Hijjah, (5) Stoning the Jamarat (devils), (6) Animal sacrifice (Qurbani), (7) Shaving/cutting hair. The Prophet (PBUH) said: 'Whoever performs Hajj and does not commit any obscenity or transgression, he returns as the day his mother bore him.' (Bukhari & Muslim).",
    source: "Sahih al-Bukhari 1521, Sahih Muslim 1350",
    category: "fiqh",
  },
  {
    keywords: ["tayammum", "dry ablution", "no water", "sand", "dust"],
    title: "Tayammum — Dry Ablution",
    answer: "Tayammum is the dry purification using clean earth/sand when water is unavailable or its use would cause harm. The Quran says: 'And if you are ill or on a journey or one of you comes from the place of relieving himself or you have contacted women and do not find water, then seek clean earth and wipe over your faces and hands with it.' (5:6). Steps: (1) Intention, (2) Strike hands on clean earth/sand, (3) Wipe over face, (4) Wipe over hands up to wrists. It remains valid until water becomes available or the excuse is removed. One strike is sufficient for the entire tayammum.",
    source: "Quran 5:6, Sahih al-Bukhari 334, Sahih Muslim 368",
    category: "fiqh",
  },
  {
    keywords: ["funeral prayer", "janazah", "salat al-janazah", "dead", "deceased", "burial"],
    title: "Salat al-Janazah — The Funeral Prayer",
    answer: "Salat al-Janazah (funeral prayer) is a Fard Kifayah (communal obligation) performed for every deceased Muslim. It has no Ruku' or Sujud. It consists of: (1) Four Takbirs, (2) After 1st Takbir: recite Al-Fatiha, (3) After 2nd Takbir: send blessings on the Prophet (PBUH), (4) After 3rd Takbir: make dua for the deceased, (5) After 4th Takbir: make a general dua, (6) Tasleem to both sides. The Prophet (PBUH) said: 'When a person dies, his deeds end except for three: ongoing charity (Sadaqah Jariyah), beneficial knowledge, and a righteous child who prays for him.' (Muslim). Visiting graves reminds us of the Hereafter.",
    source: "Sahih al-Bukhari 1247, Sahih Muslim 945, 1631",
    category: "fiqh",
  },
  {
    keywords: ["witr", "witr prayer", "night prayer", "qiyam", "tahajjud"],
    title: "Witr and Tahajjud (Night Prayers)",
    answer: "Witr prayer is an odd-numbered prayer performed after Isha. The Prophet (PBUH) said: 'Allah is Witr (One/Unique) and He loves the Witr, so perform the Witr prayer, O people of the Quran!' (Tirmidhi, Abu Dawud, Nasa'i). It can be 1, 3, 5, 7, 9, or 11 Rak'ahs, with the most common being 3 Rak'ahs. Tahajjud (Qiyam al-Layl) is the voluntary night prayer performed after waking up from sleep, ideally in the last third of the night. The Prophet (PBUH) said: 'The best prayer after the obligatory prayers is the night prayer.' (Muslim). In Ramadan, Qiyam is called Taraweeh and is performed in congregation.",
    source: "Sunan al-Tirmidhi 453, Sahih Muslim 1163",
    category: "fiqh",
  },
  {
    keywords: ["sadaqah", "voluntary charity", "giving", "donation", "help poor"],
    title: "Sadaqah — Voluntary Charity",
    answer: "Sadaqah is voluntary charity beyond the obligatory Zakat. The Prophet (PBUH) said: 'Charity does not decrease wealth.' (Muslim). He also said: 'The believer's shade on the Day of Resurrection will be his charity.' (Tirmidhi). Sadaqah can be given in many forms: money, food, a smile, removing harm from the road, sharing knowledge, or even a kind word. The Prophet (PBUH) said: 'Every good deed is charity.' (Bukhari). Sadaqah Jariyah (ongoing charity) — such as building a well, school, or mosque — continues to earn rewards even after death.",
    source: "Sahih Muslim 2588, Sunan al-Tirmidhi 1926, Sahih al-Bukhari 6021",
    category: "fiqh",
  },
  {
    keywords: ["halal food", "haram food", "dietary", "permissible", "prohibited", "meat", "alcohol", "pork"],
    title: "Halal and Haram Food in Islam",
    answer: "Islamic dietary laws are clearly defined. Haram (forbidden) foods include: (1) Pork and pork products, (2) Blood, (3) Carrion (dead animals not slaughtered properly), (4) Animals slaughtered without mentioning Allah's name, (5) Alcohol and all intoxicants — 'Every intoxicant is khamr, and every khamr is haram.' (Muslim). Halal (permissible) meat requires: (1) The animal must be slaughtered by a Muslim, Christian, or Jew, (2) Bismillah Allahu Akbar must be said, (3) The throat must be cut with a sharp instrument, (4) Blood must drain completely. Fish and seafood are generally permissible. The Prophet (PBUH) said: 'Verily, Allah has prescribed excellence in everything.' (Muslim). Muslims should eat halal, say Bismillah before eating, and eat with the right hand.",
    source: "Quran 2:173, 5:3, 5:90, Sahih Muslim 2003",
    category: "fiqh",
  },
  {
    keywords: ["sunnah fasting", "monday", "thursday", "white days", "ayyam al-beedh"],
    title: "Recommended Fasting Days (Beyond Ramadan)",
    answer: "Beyond Ramadan, the Prophet (PBUH) regularly fasted: (1) Mondays — 'That is the day on which I was born, and the day on which I was sent revelation.' (Muslim), (2) Thursdays — 'Deeds are presented on Mondays and Thursdays, and I like that my deeds be presented while I am fasting.' (Tirmidhi), (3) The White Days (Ayyam al-Beedh) — 13th, 14th, 15th of every lunar month, (4) The 6 days of Shawwal after Eid al-Fitr — 'Whoever fasts Ramadan and then follows it with six days of Shawwal, it is as if he fasted the entire year.' (Muslim), (5) The Day of Arafah (9th Dhul-Hijjah) for non-pilgrims — 'It expiates the sins of the past year and the coming year.' (Muslim), (6) The 10th of Muharram (Ashura) — 'I hope that Allah will accept it as expiation for the year before.' (Muslim).",
    source: "Sahih Muslim 1162, 1164, 2744, Sunan al-Tirmidhi 745",
    category: "fiqh",
  },
  {
    keywords: ["mahr", "dowry", "wedding", "nikah", "marriage in islam", "spouse", "wife", "husband"],
    title: "Marriage (Nikah) in Islam",
    answer: "Marriage (Nikah) is half of faith in Islam. The Prophet (PBUH) said: 'Marriage is part of my Sunnah. Whoever does not follow my Sunnah is not of me.' (Ibn Majah). He also said: 'When a servant marries, he has completed half of his faith, so let him fear Allah in the other half.' (Bayhaqi). Key requirements: (1) Consent of both parties, (2) Mahr (dowry) given by the groom to the bride, (3) Wali (guardian) for the bride, (4) Two Muslim witnesses, (5) Khutbah (sermon). Islam encourages marrying early, choosing based on deen (religiosity), and treating one's spouse with kindness. The Prophet (PBUH) said: 'The best of you is the best to his wife.' (Tirmidhi).",
    source: "Sunan Ibn Majah 1846, Sunan al-Tirmidhi 1163",
    category: "fiqh",
  },
  // AQEEDAH
  {
    keywords: ["aqeedah", "creed", "belief", "faith", "iman", "articles of faith"],
    title: "Aqeedah — Islamic Creed",
    answer: "Aqeedah refers to the firm, unshakable beliefs of Islam. The Six Articles of Faith (Arkan al-Iman) are: (1) Belief in Allah (Tawhid), (2) Belief in His Angels, (3) Belief in His Books (Quran, Torah, Gospel, Psalms, Scrolls), (4) Belief in His Messengers (25 mentioned by name, starting with Adam and ending with Muhammad), (5) Belief in the Last Day (Day of Judgment, Paradise, Hellfire), (6) Belief in Divine Decree (Qadar) — both good and bad. The Prophet (PBUH) said to Jibreel: 'Iman is to believe in Allah, His Angels, His Books, His Messengers, the Last Day, and in the Divine Decree — both good and bad.' (Muslim).",
    source: "Sahih Muslim 8, Sahih al-Bukhari 50",
    category: "aqeedah",
  },
  {
    keywords: ["tawhid", "oneness of allah", "shirk", "associating partners", "la ilaha illallah"],
    title: "Tawhid — The Oneness of Allah",
    answer: "Tawhid is the foundation of Islam — the belief in the absolute Oneness of Allah. It has three categories: (1) Tawhid ar-Rububiyyah — Allah is the sole Creator, Provider, and Sustainer of everything. (2) Tawhid al-Uluhiyyah — Allah alone deserves all worship. No one/nothing else can be worshipped. (3) Tawhid al-Asma wa as-Sifat — Allah has unique names and attributes as described in the Quran and authentic Sunnah, without distortion, denial, or comparison to creation. The Prophet (PBUH) said: 'Whoever says La ilaha illallah sincerely from his heart will enter Paradise.' (Bukhari & Muslim). Shirk (associating partners with Allah) is the greatest sin and is unforgivable if one dies upon it without repentance.",
    source: "Quran 4:48, Sahih al-Bukhari 123, Sahih Muslim 29",
    category: "aqeedah",
  },
  {
    keywords: ["angels", "malaika", "jibreel", "mikaeel", "israfeel", "azrael"],
    title: "Belief in Angels (Mala'ikah)",
    answer: "Angels are creations of Allah made from light (Noor). They are pure beings who never disobey Allah. Key angels include: (1) Jibreel (Gabriel) — brought revelation to prophets, (2) Mikaeel (Michael) — responsible for rain and sustenance, (3) Israfeel — will blow the Trumpet on Judgment Day, (4) Azrael (Malak al-Mawt) — the Angel of Death, (5) Ridwan — guardian of Paradise, (6) Malik — guardian of Hellfire, (7) Munkar and Nakir — question the deceased in the grave, (8) Kiraman Katibin — the two recording angels (one on the right, one on the left). The Prophet (PBUH) was given permission to see Jibreel in his true form twice — filling the entire horizon with 600 wings.",
    source: "Quran 2:98, 32:11, Sahih al-Bukhari 3234, Sahih Muslim 177",
    category: "aqeedah",
  },
  {
    keywords: ["qadar", "destiny", "divine decree", "predestination", "fate"],
    title: "Belief in Qadar (Divine Decree)",
    answer: "Qadar means Allah's complete knowledge and predestination of everything. It has four levels: (1) Al-Ilm al-Qadeem — Allah's eternal knowledge of everything that was, is, and will be, (2) Kitabah — Writing in the Preserved Tablet (Al-Lawh al-Mahfudh), (3) Mashiyyah — Allah's will that nothing happens without His permission, (4) Khalq — Creation and bringing into existence. The Prophet (PBUH) said: 'Iman is to believe in... the Divine Decree — both good and bad.' (Muslim). Belief in Qadar means: we have free will and are responsible for our choices, yet everything occurs by Allah's will and knowledge. 'Say: Nothing will ever befall us except what Allah has ordained for us.' (9:51)",
    source: "Quran 9:51, 57:22, Sahih Muslim 8",
    category: "aqeedah",
  },
  {
    keywords: ["jannah", "paradise", "heaven", "firdaus", "eternal life", "hereafter"],
    title: "Paradise (Jannah / Firdaus)",
    answer: "Jannah (Paradise) is the eternal abode of bliss for believers. The highest level is Firdaus al-A'la, which the Prophet (PBUH) asked Allah for: 'When you ask Allah for Paradise, ask for Firdaus al-A'la, for it is the highest part of Paradise, and from it the rivers of Paradise flow, and above it is the Throne of the Most Merciful.' (Bukhari). Jannah contains what 'no eye has seen, no ear has heard, and no mind has imagined' (Muslim). Its delights include: rivers of milk, honey, wine (non-intoxicating), and pure water; fruits of every kind; palaces of gold and silver; being with the Prophets; and most importantly — seeing the Face of Allah. Every person in Jannah will be 33 years old, in the best form, with no sickness, sorrow, or death.",
    source: "Sahih al-Bukhari 2790, Sahih Muslim 282, 283",
    category: "aqeedah",
  },
  {
    keywords: ["hellfire", "jahannam", "fire", "punishment", "doom", "accountability"],
    title: "Hellfire (Jahannam)",
    answer: "Jahannam is the eternal abode of punishment for disbelievers and some sinful Muslims (until Allah wills otherwise). It has seven levels with varying degrees of punishment. The lowest level is for hypocrites. The Quran describes its gates, guards (angels of punishment), boiling water, scorching wind, and chains. However, Allah's mercy encompasses His anger. The Prophet (PBUH) said: 'No one will enter Paradise because of his deeds.' They asked: 'Not even you, O Messenger of Allah?' He said: 'Not even me, unless Allah envelops me in His mercy.' (Bukhari & Muslim). The ultimate punishment is being deprived of seeing Allah. Muslims who enter due to sins will eventually be taken out through the intercession of the Prophet (PBUH).",
    source: "Quran 15:44, Sahih al-Bukhari 5673, Sahih Muslim 2816",
    category: "aqeedah",
  },
  {
    keywords: ["day of judgment", "qiyamah", "qiyama", "last day", "resurrection", "afterlife"],
    title: "The Day of Judgment (Yawm al-Qiyamah)",
    answer: "Yawm al-Qiyamah is the Day when all of humanity will be resurrected and held accountable. Major signs include: the Mahdi, the Dajjal (Antichrist), the descent of Prophet Isa (Jesus), Yajuj and Majuj (Gog and Magog), the Beast (Dabba), the rising of the sun from the west, and the smoke. On that Day: (1) The Trumpet will be blown by Israfeel, (2) All creation will die, then be resurrected, (3) People will be gathered naked and barefoot, (4) The scales (Mizan) will weigh deeds, (5) The Sirat (bridge over Hellfire) will be crossed, (6) The Hawd (Pool) of the Prophet (PBUH) will quench the believers' thirst. The Quran describes it as a day 50,000 years long for the disbelievers. 'The Day when every soul will find present whatever it did of good and evil.' (3:30)",
    source: "Quran 3:30, 22:1-2, Sahih al-Bukhari 4939, Sahih Muslim 2937",
    category: "aqeedah",
  },
  {
    keywords: ["death", "dying", "grave", "barzakh", "hereafter", "akhirah"],
    title: "Death and the Grave (Barzakh)",
    answer: "Death is the transition from this world to the Hereafter. The Prophet (PBUH) said: 'Remember often the destroyer of pleasures — death.' (Tirmidhi, Nasa'i). After death, the soul enters Barzakh — the intermediate state until Resurrection. Two angels (Munkar and Nakir) question the deceased: 'Who is your Lord? What is your religion? Who is your Prophet?' The believer answers confidently, while the disbeliever cannot. The grave is either a garden of Paradise or a pit of Hellfire. The Prophet (PBUH) said: 'The grave is the first of the stages of the Hereafter. Whoever is saved from it, what comes after is easier. And whoever is not saved from it, what comes after is harder.' (Tirmidhi, Ibn Majah). Actions that benefit the deceased: dua, charity on their behalf, Quran recitation, and Hajj/Badl.",
    source: "Sunan al-Tirmidhi 2307, Sunan Ibn Majah 4262",
    category: "aqeedah",
  },
  {
    keywords: ["prophets", "prophethood", "messengers", "nabi", "rasul", "adam", "noah", "moses", "jesus", "ibrahim"],
    title: "Prophets and Messengers of Allah",
    answer: "Allah sent 124,000+ prophets, with 25 mentioned by name in the Quran: Adam, Idris (Enoch), Nuh (Noah), Hud, Salih, Ibrahim (Abraham), Lut (Lot), Ismail (Ishmael), Ishaq (Isaac), Yaqub (Jacob), Yusuf (Joseph), Ayyub (Job), Shuaib, Musa (Moses), Harun (Aaron), Dhul-Kifl, Dawud (David), Sulayman (Solomon), Ilyas (Elijah), Al-Yasa (Elisha), Yunus (Jonah), Zakariya (Zechariah), Yahya (John), Isa (Jesus), and Muhammad (PBUH). A Rasul (Messenger) brings a new scripture; a Nabi (Prophet) follows previous scripture. The Prophet (PBUH) said: 'I have been given superiority over the other prophets in six respects...' (Bukhari & Muslim). He is Khatam al-Nabiyyin (the Seal of the Prophets) — no prophet will come after him.",
    source: "Quran 33:40, Sahih al-Bukhari 3353, Sahih Muslim 523",
    category: "aqeedah",
  },
  {
    keywords: ["jinn", "shaytan", "devil", "evil eye", "hasad", "black magic", "sihr", "ruqyah"],
    title: "Jinn, Shaytan, Evil Eye, and Ruqyah",
    answer: "Jinn are unseen beings created from smokeless fire, like humans they have free will and can be Muslim or non-Muslim. Shaytan (Iblis) is a jinn who refused to prostrate to Adam. He whispers evil thoughts but cannot force anyone to sin. The Prophet (PBUH) said: 'Allah has not created a disease without creating its cure.' (Bukhari). The Evil Eye (Al-Ayn) is real — 'the evil eye is real' (Bukhari). Protection methods: (1) Reciting the last 3 Surahs (Ikhlas, Falaq, Nas) 3 times morning and evening, (2) Ayat al-Kursi, (3) 'Bismillahi alladhi la yadurru ma'asmihi shay'un fil-ardi wa la fis-sama'i' (3 times), (4) Ruqyah (spiritual healing) with Quran and authentic dua. Treatment for magic (Sihr): Ruqyah with Surah Al-Fatiha, Ayat al-Kursi, the last 2 Surahs, and authentic supplications.",
    source: "Sahih al-Bukhari 3280, 5740, Sahih Muslim 2187, 2190",
    category: "aqeedah",
  },
  {
    keywords: ["taubah", "repentance", "istighfar", "forgiveness", "astaghfirullah", "sin", "sins"],
    title: "Tawbah (Repentance) — Returning to Allah",
    answer: "Tawbah (repentance) is a fundamental concept in Islam. Allah loves those who repent: 'Indeed, Allah loves those who are constantly repentant and loves those who purify themselves.' (2:222). The conditions for sincere repentance are: (1) Stopping the sin immediately, (2) Feeling sincere regret, (3) Resolving never to return to it, (4) If the sin involved violating others' rights, one must restore those rights or seek forgiveness. The Prophet (PBUH) said: 'Allah is more pleased with the repentance of His servant than one of you who finds his lost camel in the desert.' (Bukhari & Muslim). Allah says: 'Say, O My servants who have transgressed against themselves, do not despair of the mercy of Allah. Indeed, Allah forgives all sins.' (39:53). Saying Astaghfirullah 100 times daily is highly recommended.",
    source: "Quran 39:53, 2:222, Sahih al-Bukhari 6309, Sahih Muslim 2747",
    category: "aqeedah",
  },
  // SEERAH
  {
    keywords: ["prophet muhammad", "rasulullah", "messenger", "seerah", "biography"],
    title: "Prophet Muhammad (PBUH) — His Life",
    answer: "Prophet Muhammad ibn Abdullah (PBUH) was born in Makkah in the Year of the Elephant (570 CE) on a Monday in the month of Rabi' al-Awwal. His father Abdullah died before his birth, and his mother Aminah died when he was six. He was raised by his grandfather Abdul Muttalib and then his uncle Abu Talib. At 40, he received the first revelation in the Cave of Hira through Angel Jibreel. He preached in Makkah for 13 years, then migrated (Hijrah) to Madinah where he established the first Islamic state. He participated in battles for self-defense, made treaties, and sent letters to kings inviting them to Islam. He passed away at age 63 in Madinah. The Prophet (PBUH) said: 'I have been sent to perfect noble character.' (Muwatta). He is the best of creation and the Seal of all Prophets.",
    source: "Ar-Raheeq al-Makhtum, Sahih Bukhari & Muslim",
    category: "seerah",
  },
  {
    keywords: ["birth of prophet", "mawlid", "12 rabi", "monday"],
    title: "The Birth of the Prophet (PBUH)",
    answer: "Prophet Muhammad (PBUH) was born on a Monday in Rabi' al-Awwal in the Year of the Elephant (570 CE). When asked about fasting on Monday, he said: 'That is the day on which I was born, and the day on which I was sent revelation.' (Muslim). His birth was accompanied by miraculous signs: the idols of the Kaaba fell, the fire-worshippers of Persia saw their sacred fire extinguished, and the palace of Chosroes shook. His grandfather Abdul Muttalib named him Muhammad (the praised one) and Ahmad (the one who praises most).",
    source: "Sahih Muslim 1162, Ar-Raheeq al-Makhtum",
    category: "seerah",
  },
  {
    keywords: ["hijrah", "migration", "madinah", "medina", "yathrib"],
    title: "The Hijrah — Migration to Madinah",
    answer: "The Hijrah is the migration of the Prophet (PBUH) and Muslims from Makkah to Madinah in 622 CE. It marks the beginning of the Islamic calendar. After years of persecution in Makkah, Allah permitted migration. The Prophet (PBUH) and Abu Bakr (RA) secretly left, with Imam Ali (RA) sleeping in the Prophet's bed as a decoy. They took refuge in the Cave of Thawr for three days while the Quraysh searched. A spider wove a web at the cave's entrance, and a pigeon laid eggs, convincing the pursuers no one was inside. Upon arrival in Madinah, the Prophet (PBUH) established the Constitution of Madinah, creating the first pluralistic state. The Hijrah transformed a persecuted minority into a thriving community.",
    source: "Ar-Raheeq al-Makhtum, Sahih al-Bukhari 3905",
    category: "seerah",
  },
  {
    keywords: ["khulafa rashidun", "rightly guided caliphs", "abu bakr", "umar", "uthman", "ali"],
    title: "The Khulafa al-Rashidun — Rightly Guided Caliphs",
    answer: "The Khulafa al-Rashidun (Rightly Guided Caliphs) are the four successors of the Prophet (PBUH) who ruled according to his Sunnah: (1) Abu Bakr as-Siddiq (RA) — ruled 2 years, compiled the Quran, fought apostasy wars. (2) Umar ibn al-Khattab (RA) — ruled 10 years, established the Islamic calendar, expanded territories, created welfare systems. (3) Uthman ibn Affan (RA) — ruled 12 years, standardized the Quran (Mushaf), expanded navy. (4) Ali ibn Abi Talib (RA) — ruled 5 years, known for deep knowledge, justice, and wisdom. The Prophet (PBUH) said: 'The Caliphate will remain in my Ummah for thirty years, then there will be kingship after that.' (Tirmidhi, Abu Dawud). Together they ruled approximately 30 years.",
    source: "Sunan al-Tirmidhi 2226, Sunan Abu Dawud 4646",
    category: "seerah",
  },
  {
    keywords: ["companions", "sahaba", "sahabi", "righteous predecessors", "salaf"],
    title: "The Sahaba (Companions)",
    answer: "The Sahaba (Companions) are those who met the Prophet (PBUH) as believers and died upon Islam. They are the best generation of Muslims. The Prophet (PBUH) said: 'The best of people are my generation, then those who follow them, then those who follow them.' (Bukhari & Muslim). There are approximately 114,000 Sahaba. The ten promised Paradise (al-Ashara al-Mubashshara) are: Abu Bakr, Umar, Uthman, Ali, Talhah, Zubayr, Abdur Rahman ibn Awf, Sa'd ibn Abi Waqqas, Sa'id ibn Zayd, and Abu Ubaydah ibn al-Jarrah. Others include: Bilal ibn Rabah (first Mu'adhin), Khalid ibn al-Walid (Sayfullah — Sword of Allah), Salman al-Farsi, Abu Hurayrah (most hadith narrator with 5,374), and Aisha (RA) — the Mother of the Believers.",
    source: "Sahih al-Bukhari 3651, Sahih Muslim 2533",
    category: "seerah",
  },
  {
    keywords: ["badr", "uhud", "khandaq", "battle", "conquest of mecca", "battles of islam"],
    title: "Major Battles in Islamic History",
    answer: "The major battles in early Islamic history include: (1) Badr (2 AH) — 313 Muslims vs. 1000 Quraysh. Muslims won decisively despite being outnumbered. Allah sent angels to assist. (2) Uhud (3 AH) — Muslims initially winning, but archers disobeying orders led to a setback. The Prophet (PBUH) was wounded. Lesson: Obedience is crucial. (3) Khandaq/Ahzab (5 AH) — A trench was dug around Madinah (Salman al-Farsi's idea). The coalition of tribes was defeated without direct combat. (4) Conquest of Makkah (8 AH) — The Prophet (PBUH) entered Makkah with 10,000 soldiers, conquered it almost bloodlessly, and forgave his enemies, saying: 'Go, you are free.' These battles were all defensive or to establish security.",
    source: "Ar-Raheeq al-Makhtum, Sahih al-Bukhari, Sahih Muslim",
    category: "seerah",
  },
  // ETHICS
  {
    keywords: ["adab", "manners", "character", "akhlaq", "morality", "noble character"],
    title: "Adab — Islamic Manners and Character",
    answer: "Islam places great emphasis on good character (Akhlaq). The Prophet (PBUH) said: 'I have been sent to perfect noble character.' (Muwatta). He also said: 'The best of you are those with the best character.' (Bukhari). Key Islamic manners include: (1) Greeting with 'As-salamu alaykum' — the greeting of Paradise, (2) Saying Bismillah before eating and Alhamdulillah after, (3) Using the right hand for eating and giving, (4) Removing harm from the road is charity, (5) Lowering the gaze, (6) Honoring parents — 'Paradise lies at the feet of mothers' (Nasa'i), (7) Keeping promises, (8) Being truthful, (9) Forgiving others, (10) Having patience (Sabr) and gratitude (Shukr).",
    source: "Al-Muwatta, Sahih al-Bukhari 6035, Sahih Muslim 2321",
    category: "ethics",
  },
  {
    keywords: ["parents", "mother", "father", "jannah", "bir al-walidayn", "kindness"],
    title: "Birr al-Walidayn — Kindness to Parents",
    answer: "Honoring parents (Birr al-Walidayn) is one of the greatest obligations in Islam, mentioned alongside Tawhid. Allah says: 'Worship Allah and associate nothing with Him, and be kind to parents.' (4:36). The Prophet (PBUH) said: 'Paradise lies at the feet of mothers.' (Nasa'i). Another hadith says: 'The pleasure of the Lord lies in the pleasure of the parent, and the displeasure of the Lord lies in the displeasure of the parent.' (Tirmidhi). Even if parents are non-Muslim, Muslims must treat them with excellence (Ihsan), though without following them in disbelief. After their death, making dua for them, giving charity on their behalf, and maintaining ties with their relatives continues to benefit them.",
    source: "Quran 4:36, 17:23-24, Sunan al-Nasa'i 3104, Sunan al-Tirmidhi 1899",
    category: "ethics",
  },
  {
    keywords: ["forgiveness", "pardon", "afw", "mercy", "let go", "anger"],
    title: "Forgiveness in Islam",
    answer: "Islam teaches that forgiveness is a noble virtue. Allah describes Himself as Al-Ghafur (the Forgiving) and Al-Afuww (the Pardoner). The Prophet (PBUH) said: 'The strong man is not the one who can wrestle others down. The strong man is the one who can control himself when he is angry.' (Bukhari). The Quran commands: 'Let them pardon and overlook. Would you not like that Allah should forgive you?' (24:22). The Prophet (PBUH) forgave the people of Makkah who had persecuted him for 21 years, saying 'Go, you are free.' Forgiveness does not mean accepting injustice — it means freeing oneself from the burden of resentment while upholding justice where needed.",
    source: "Quran 24:22, Sahih al-Bukhari 6114, Sahih Muslim 2609",
    category: "ethics",
  },
  {
    keywords: ["sabr", "patience", "shukr", "gratitude", "perseverance", "hardship"],
    title: "Sabr (Patience) and Shukr (Gratitude)",
    answer: "Sabr (patience) and Shukr (gratitude) are two wings of a believer. The Quran says: 'Indeed, the patient will be given their reward without account.' (39:10). Patience has three types: (1) Patience in worshipping Allah, (2) Patience in avoiding sins, (3) Patience during calamities. The Prophet (PBUH) said: 'How wonderful is the affair of the believer! For all of his affairs are good. If good befalls him, he is grateful, and that is good for him. If harm befalls him, he is patient, and that is good for him.' (Muslim). Shukr means using Allah's blessings in obedience to Him and acknowledging that everything good is from Him. 'If you are grateful, I will surely increase you.' (14:7)",
    source: "Quran 14:7, 39:10, Sahih Muslim 2999",
    category: "ethics",
  },
  {
    keywords: ["greeting", "assalamu alaikum", "salam", "peace"],
    title: "Islamic Greeting — As-salamu alaykum",
    answer: "As-salamu alaykum wa rahmatullahi wa barakatuh (Peace, mercy, and blessings of Allah be upon you) is the greeting of Islam and the greeting of the people of Paradise. The Prophet (PBUH) said: 'You will not enter Paradise until you believe, and you will not believe until you love one another. Shall I tell you of something which, if you do it, you will love one another? Spread the greeting of peace among yourselves.' (Muslim). It is Sunnah to initiate the greeting and to respond with equal or better words. When entering a house, one should greet its inhabitants. The greeting is also said when leaving a gathering.",
    source: "Sahih Muslim 54, Sahih al-Bukhari 6234",
    category: "ethics",
  },
  // DUA
  {
    keywords: ["dua", "supplication", "prayer to allah", "ask allah", "invocation"],
    title: "Dua — The Essence of Worship",
    answer: "Dua (supplication) is the essence of worship. The Prophet (PBUH) said: 'Dua is the essence of worship.' (Tirmidhi). Allah says: 'Call upon Me, I will respond to you.' (40:60). Dua can be made anytime, anywhere — there is no barrier between a servant and Allah. Best times for acceptance: (1) Last third of the night (Tahajjud time), (2) Between Adhan and Iqamah, (3) While prostrating in prayer, (4) On Fridays (especially the last hour before Maghrib), (5) While fasting, (6) During travel, (7) When rain falls, (8) After obligatory prayers. The Prophet (PBUH) said: 'Your Lord is Shy and Generous. He is Shy that when His servant raises his hands to Him, He returns them empty.' (Tirmidhi, Abu Dawud).",
    source: "Quran 40:60, Sunan al-Tirmidhi 3372, Sunan Abu Dawud 1485",
    category: "dua",
  },
  {
    keywords: ["morning adhkar", "evening adhkar", "daily dhikr", "remembrance", "tasbih"],
    title: "Daily Adhkar (Morning & Evening Remembrances)",
    answer: "The Prophet (PBUH) taught specific Adhkar (remembrances) for morning (after Fajr until sunrise) and evening (after Asr until sunset). Key ones include: (1) Ayat al-Kursi (2:255) — recite once, (2) Surah Al-Ikhlas, Al-Falaq, An-Nas — recite 3 times each, (3) 'SubhanAllahi wa bihamdihi' (100 times), (4) 'La ilaha illallahu wahdahu la sharika lahu, lahul mulku wa lahul hamdu wa huwa ala kulli shay'in qadeer' (10 times), (5) 'Hasbunallahu wa ni'mal wakeel' (Allah is sufficient for us), (6) 'A'udhu bi kalimatillah al-tammah min sharri ma khalaq' (3 times). The Prophet (PBUH) said: 'Whoever says these words in the morning and evening, nothing will harm him.' (Tirmidhi).",
    source: "Sunan al-Tirmidhi 3388, Sahih al-Bukhari 6406, Sahih Muslim 2713",
    category: "dua",
  },
  {
    keywords: ["tasbih", "tahmid", "takbir", "tahlil", "subhanallah", "alhamdulillah", "allahu akbar", "la ilaha illallah"],
    title: "The Four Words of Dhikr",
    answer: "The four greatest words of remembrance are: (1) SubhanAllah (Glory be to Allah) — declares Allah's perfection, (2) Alhamdulillah (Praise be to Allah) — expresses gratitude, (3) Allahu Akbar (Allah is the Greatest) — acknowledges His greatness, (4) La ilaha illallah (There is no god but Allah) — the foundation of faith. The Prophet (PBUH) said: 'The most beloved words to Allah are four: SubhanAllah, Alhamdulillah, La ilaha illallah, and Allahu Akbar.' (Muslim). He also said: 'Whoever says SubhanAllahi wa bihamdihi 100 times a day, his sins will be forgiven even if they are like the foam of the sea.' (Bukhari & Muslim). These are called Tasbih, Tahmid, Takbir, and Tahlil respectively.",
    source: "Sahih Muslim 2137, Sahih al-Bukhari 6405",
    category: "dua",
  },
  {
    keywords: ["salat alan nabi", "salatun nabi", "darud", "salawat", "durood", "blessings on prophet"],
    title: "Salawat (Sending Blessings on the Prophet PBUH)",
    answer: "Sending blessings (Salawat/Durood) upon the Prophet (PBUH) is a beloved act. Allah says: 'Indeed, Allah and His angels confer blessing upon the Prophet. O you who have believed, ask [Allah to confer] blessing upon him and ask [Allah to grant him] peace.' (33:56). The most common form is: 'Allahumma salli ala Muhammadin wa ala ali Muhammadin kama sallayta ala Ibrahima wa ala ali Ibrahima innaka Hamidun Majeed. Allahumma barik ala Muhammadin wa ala ali Muhammadin kama barakta ala Ibrahima wa ala ali Ibrahima innaka Hamidun Majeed.' Benefits: (1) It earns 10 blessings from Allah, (2) 10 sins are erased, (3) 10 degrees are raised in Paradise, (4) The Prophet (PBUH) will recognize and intercede for those who sent abundant Salawat.",
    source: "Quran 33:56, Sahih al-Bukhari 6357, Sahih Muslim 408",
    category: "dua",
  },
  {
    keywords: ["salat al istikhara", "istikhara", "decision", "guidance prayer", "confused", "what to do"],
    title: "Salat al-Istikhara — Prayer for Guidance",
    answer: "Istikhara is a special prayer performed when seeking Allah's guidance in making a decision. The Prophet (PBUH) taught the dua: 'O Allah, I seek Your guidance [in making a choice] by virtue of Your knowledge, and I seek ability by virtue of Your power, and I ask You of Your great bounty...' (Bukhari). After praying 2 Rak'ahs, one makes this dua and then follows what feels most comfortable in the heart. The Prophet (PBUH) said: 'If any one of you is concerned about a decision, let him pray two Rak'ahs of non-obligatory prayer, then say: O Allah, I ask You for the good through Your knowledge...' The result of Istikhara may appear as a feeling of ease toward the right choice or as circumstances unfolding naturally.",
    source: "Sahih al-Bukhari 1166",
    category: "dua",
  },
  // HISTORY
  {
    keywords: ["golden age", "islamic civilization", "science", "contributions", "islamic scholars"],
    title: "Islamic Golden Age — Contributions to Civilization",
    answer: "The Islamic Golden Age (8th-14th centuries) was a period when Muslim scholars made groundbreaking contributions to human civilization. Key achievements include: (1) Medicine — Ibn Sina (Avicenna) wrote 'The Canon of Medicine' used in Europe for 600 years. Al-Razi (Rhazes) identified smallpox and measles. (2) Mathematics — Al-Khwarizmi invented Algebra (from Arabic 'al-Jabr') and introduced the concept of zero from India. (3) Astronomy — Al-Battani calculated the solar year with precision. (4) Chemistry — Jabir ibn Hayyan established the experimental method. (5) Optics — Ibn al-Haytham proved light travels in straight lines. (6) Law — Islamic jurisprudence developed systematic legal methodology. (7) Universities — Al-Azhar (970 CE) is the world's oldest continuously operating university. The Prophet (PBUH) said: 'Wisdom is the lost property of the believer.' (Tirmidhi).",
    source: "Various historical sources, Sunan al-Tirmidhi 2687",
    category: "history",
  },
  {
    keywords: ["masjid al-aqsa", "aqsa", "jerusalem", "bait al-maqdis", "isra miraj", "first qibla"],
    title: "Masjid al-Aqsa — The First Qibla",
    answer: "Masjid al-Aqsa in Jerusalem was the first Qibla (direction of prayer) for Muslims for 16 months before it was changed to the Kaaba. The Prophet (PBUH) said: 'Do not undertake a journey except to three mosques: Masjid al-Haram, this mosque of mine, and Masjid al-Aqsa.' (Bukhari & Muslim). It is the site of the Isra and Mi'raj — the miraculous Night Journey and Ascension to the heavens where the Prophet (PBUH) led all prophets in prayer and met Allah directly. The Quran describes it: 'Glory be to Him who took His servant by night from Masjid al-Haram to Masjid al-Aqsa, whose surroundings We have blessed...' (17:1). It is the third holiest site in Islam after Makkah and Madinah.",
    source: "Quran 17:1, Sahih al-Bukhari 1189, Sahih Muslim 1397",
    category: "history",
  },
  {
    keywords: ["zamzam", "zam zam", "hajar", "ismael", "mecca water", "blessed water"],
    title: "Zamzam Water — The Blessed Water of Makkah",
    answer: "Zamzam is the miraculously generated water from a well in Masjid al-Haram, Makkah. It originated when Hajar (Hagar), wife of Ibrahim (AS), ran between Safa and Marwah searching for water for her son Ismail (AS). Baby Ismail scraped the ground with his heel and the water gushed forth. The Prophet (PBUH) said: 'Zamzam water is for whatever purpose it is drunk for.' (Ibn Majah). He also said: 'The best water on the face of the earth is Zamzam water. In it is food for the hungry and a cure for the sick.' (Tabarani). It has been flowing continuously for over 4,000 years and has never dried up. Running between Safa and Marwah (Sa'i) commemorates Hajar's search and is an essential ritual of Hajj and Umrah.",
    source: "Sunan Ibn Majah 3062, Al-Mu'jam al-Awsat by Tabarani",
    category: "history",
  },
  // GENERAL
  {
    keywords: ["music", "singing", "nasheed", "instruments", "halal haram music"],
    title: "Islamic Ruling on Music",
    answer: "According to the majority of classical scholars (Hanafi, Maliki, Shafi'i, Hanbali), musical instruments are prohibited except the duff (one-sided drum) in specific celebrations (weddings, Eid). The Prophet (PBUH) said: 'From among my followers there will be some people who will consider illegal sexual intercourse, the wearing of silk, the drinking of alcoholic drinks, and the use of musical instruments as lawful.' (Bukhari). However, Islamic Nasheeds (vocals only, without instruments) are widely encouraged. Some contemporary scholars differentiate between music that promotes immorality (clearly haram) and cultural music. The safest position for a practicing Muslim is to avoid instrumental music and listen to Quran recitation, Nasheeds, and Islamic lectures.",
    source: "Sahih al-Bukhari 5590, various classical fiqh texts",
    category: "general",
  },
  {
    keywords: ["dreams", "ru'ya", "true dream", "interpretation"],
    title: "Dreams in Islam (Ru'ya)",
    answer: "The Prophet (PBUH) said: 'Dreams are of three types: (1) True dreams (Ru'ya) from Allah — glad tidings for the believer, (2) Dreams from Shaytan that cause distress and fear, (3) Dreams from one's own thoughts and desires.' (Bukhari). Good dreams should be shared only with loved ones. Bad dreams should not be shared with anyone — instead, spit (dryly) to the left three times, seek refuge with Allah from its evil, and turn to the other side. The Prophet (PBUH) received Wahy (revelation) through true dreams for 6 months before prophethood — 'he would not see a dream except that it would occur like the break of dawn.' (Bukhari).",
    source: "Sahih al-Bukhari 6987, Sahih Muslim 2261",
    category: "general",
  },
  {
    keywords: ["governance", "sharia", "islamic state", "caliphate", "khilafah", "politics", "leadership"],
    title: "Islamic Governance and Shariah",
    answer: "Islam provides a comprehensive framework for governance. The Quran and Sunnah are the primary sources of legislation. Key principles include: (1) Justice (Adl) — 'Indeed, Allah commands you to render trusts to whom they are due and when you judge between people to judge with justice.' (4:58), (2) Shura (Consultation) — 'And those who have responded to their Lord and established prayer and whose affair is [determined by] consultation among themselves.' (42:38), (3) Protection of life, property, honor, and religion, (4) Accountability of rulers — Umar (RA) said: 'If a mule stumbles on the Euphrates, I fear Allah will ask me why I did not pave the road.' The Prophet (PBUH) said: 'The best of your rulers are those whom you love and who love you, and the worst of your rulers are those whom you hate and who hate you.' (Muslim).",
    source: "Quran 4:58, 42:38, Sahih Muslim 1855",
    category: "general",
  },
];

// Category counts
const CATEGORY_COUNTS: Record<string, number> = {};
for (const entry of ISLAMIC_KNOWLEDGE) {
  CATEGORY_COUNTS[entry.category] = (CATEGORY_COUNTS[entry.category] || 0) + 1;
}

// Helper function to find best matching knowledge entry
function findKnowledge(query: string): KnowledgeEntry | null {
  const normalizedQuery = query.toLowerCase().trim();
  const queryWords = normalizedQuery.split(/\s+/).filter((w) => w.length > 2);

  let bestMatch: KnowledgeEntry | null = null;
  let bestScore = 0;

  for (const entry of ISLAMIC_KNOWLEDGE) {
    let score = 0;
    for (const word of queryWords) {
      for (const kw of entry.keywords) {
        if (kw.includes(word) || word.includes(kw)) score += 3;
      }
      if (entry.title.toLowerCase().includes(word)) score += 2;
      if (entry.answer.toLowerCase().includes(word)) score += 1;
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = entry;
    }
  }

  return bestScore >= 2 ? bestMatch : null;
}

function getAIResponse(message: string): { response: string; matchedEntry: string | null } {
  const lower = message.toLowerCase();
  const words = lower.split(/\s+/);

  // First try the knowledge base
  const knowledge = findKnowledge(message);
  if (knowledge) {
    const response = `${knowledge.answer}\n\n📖 **Source:** ${knowledge.source}\n📂 **Category:** ${knowledge.category.charAt(0).toUpperCase() + knowledge.category.slice(1)}`;
    return { response, matchedEntry: knowledge.title };
  }

  // Simple keyword matching for categories
  const categoryKeywords: Record<string, string> = {
    quran: "The Quran is the verbatim word of Allah, revealed to Prophet Muhammad (PBUH) over 23 years. It contains 114 Surahs and is preserved in its original Arabic. Would you like to know about a specific Surah? I can tell you about Surah Al-Fatiha, Al-Ikhlas, Al-Kahf, Yasin, Al-Mulk, Ayat al-Kursi, or any other Surah.",
    surah: "The Quran is the verbatim word of Allah, revealed to Prophet Muhammad (PBUH) over 23 years. It contains 114 Surahs and is preserved in its original Arabic. Would you like to know about a specific Surah? I can tell you about Surah Al-Fatiha, Al-Ikhlas, Al-Kahf, Yasin, Al-Mulk, Ayat al-Kursi, or any other Surah.",
    ayah: "The Quran is the verbatim word of Allah, revealed to Prophet Muhammad (PBUH) over 23 years. It contains 114 Surahs and is preserved in its original Arabic. Would you like to know about a specific Surah? I can tell you about Surah Al-Fatiha, Al-Ikhlas, Al-Kahf, Yasin, Al-Mulk, Ayat al-Kursi, or any other Surah.",
    hadith: "Hadith are the sayings, actions, and approvals of Prophet Muhammad (PBUH). The two most authentic collections are Sahih al-Bukhari and Sahih Muslim. Hadith form the second source of Islamic law after the Quran. I can also tell you about Imam al-Nawawi's 40 Hadith, the importance of intentions, and the obligation of seeking knowledge.",
    sunnah: "Hadith are the sayings, actions, and approvals of Prophet Muhammad (PBUH). The two most authentic collections are Sahih al-Bukhari and Sahih Muslim. Hadith form the second source of Islamic law after the Quran.",
    bukhari: "Sahih al-Bukhari is the most authentic book after the Quran, compiled by Imam Muhammad ibn Ismail al-Bukhari. He collected 600,000 narrations and selected 7,563 authentic hadiths. His conditions for authenticity were the strictest in hadith science.",
    fiqh: "Fiqh is Islamic jurisprudence — understanding how to apply Shariah in daily life. It covers prayer, fasting, zakat, hajj, and all aspects of worship and social dealings. The four major schools are Hanafi, Maliki, Shafi'i, and Hanbali. Ask me about Wudu, Salah, Ramadan, Zakat, Hajj, Sadaqah, or any specific topic!",
    prayer: "Fiqh is Islamic jurisprudence — understanding how to apply Shariah in daily life. It covers prayer, fasting, zakat, hajj, and all aspects of worship and social dealings. The four major schools are Hanafi, Maliki, Shafi'i, and Hanbali.",
    salah: "Fiqh is Islamic jurisprudence — understanding how to apply Shariah in daily life. It covers prayer, fasting, zakat, hajj, and all aspects of worship and social dealings. The four major schools are Hanafi, Maliki, Shafi'i, and Hanbali.",
    seerah: "Prophet Muhammad (PBUH) was born in Mecca in 570 CE. He received the first revelation at age 40 in the Cave of Hira. He is the final messenger of Allah, sent as a mercy to all mankind. His life is the best example for Muslims to follow. I can tell you about his birth, the Hijrah, the Khulafa Rashidun, the Sahaba, and major battles.",
    prophet: "Prophet Muhammad (PBUH) was born in Mecca in 570 CE. He received the first revelation at age 40 in the Cave of Hira. He is the final messenger of Allah, sent as a mercy to all mankind. His life is the best example for Muslims to follow.",
    muhammad: "Prophet Muhammad (PBUH) was born in Mecca in 570 CE. He received the first revelation at age 40 in the Cave of Hira. He is the final messenger of Allah, sent as a mercy to all mankind. His life is the best example for Muslims to follow.",
    aqeedah: "Aqeedah refers to Islamic creed and beliefs. The foundation is Tawhid — belief in the oneness of Allah. The six articles of faith are: belief in Allah, His angels, His books, His messengers, the Day of Judgment, and divine decree. Ask me about any of these topics!",
    creed: "Aqeedah refers to Islamic creed and beliefs. The foundation is Tawhid — belief in the oneness of Allah. The six articles of faith are: belief in Allah, His angels, His books, His messengers, the Day of Judgment, and divine decree.",
    tawhid: "Tawhid is the foundation of Islam — belief in the absolute Oneness of Allah. It has three categories: Tawhid ar-Rububiyyah (Lordship), Tawhid al-Uluhiyyah (Worship), and Tawhid al-Asma wa as-Sifat (Names & Attributes). Shirk is the greatest sin.",
    ramadan: "Ramadan is the ninth month of the Islamic calendar when Muslims fast from dawn to sunset. It is the month in which the Quran was revealed. Fasting is one of the Five Pillars of Islam and cultivates self-discipline, empathy, and spiritual growth.",
    fast: "Ramadan is the ninth month of the Islamic calendar when Muslims fast from dawn to sunset. It is the month in which the Quran was revealed. Fasting is one of the Five Pillars of Islam and cultivates self-discipline, empathy, and spiritual growth.",
    hajj: "Hajj is the pilgrimage to Mecca that every Muslim must perform at least once in their lifetime if physically and financially able. It occurs in Dhul-Hijjah and commemorates the actions of Prophet Ibrahim (AS) and his family.",
    zakat: "Zakat is one of the Five Pillars of Islam — an obligatory charitable contribution of 2.5% of accumulated wealth annually. It purifies wealth and helps the poor and needy. Sadaqah is voluntary charity beyond Zakat.",
    charity: "Zakat is one of the Five Pillars of Islam — an obligatory charitable contribution of 2.5% of accumulated wealth annually. It purifies wealth and helps the poor and needy. Sadaqah is voluntary charity beyond Zakat.",
    greeting: "Wa alaykumu s-salam wa rahmatullahi wa barakatuh! Peace, mercy, and blessings of Allah be upon you too. How may I assist you with your Islamic knowledge journey today?",
    assalamu: "Wa alaykumu s-salam wa rahmatullahi wa barakatuh! Peace, mercy, and blessings of Allah be upon you too. How may I assist you with your Islamic knowledge journey today?",
    salam: "Wa alaykumu s-salam wa rahmatullahi wa barakatuh! Peace, mercy, and blessings of Allah be upon you too. How may I assist you with your Islamic knowledge journey today?",
    wudu: "Wudu is the ritual purification required before prayer. The obligatory steps are: intention, washing the face, washing hands up to elbows, wiping the head, and washing feet up to ankles. Things that break wudu include passing wind, urination, deep sleep, and touching private parts.",
    ablution: "Wudu is the ritual purification required before prayer. The obligatory steps are: intention, washing the face, washing hands up to elbows, wiping the head, and washing feet up to ankles. Things that break wudu include passing wind, urination, deep sleep, and touching private parts.",
    dua: "Dua (supplication) is the essence of worship. Allah says: 'Call upon Me, I will respond to you.' (40:60). Dua can be made anytime, anywhere. Best times: last third of night, between Adhan and Iqamah, while prostrating, on Fridays, while fasting, during travel.",
    supplication: "Dua (supplication) is the essence of worship. Allah says: 'Call upon Me, I will respond to you.' (40:60). Dua can be made anytime, anywhere. Best times: last third of night, between Adhan and Iqamah, while prostrating, on Fridays, while fasting, during travel.",
    dhikr: "Dhikr (remembrance of Allah) is one of the most beloved acts. The four greatest words are: SubhanAllah, Alhamdulillah, Allahu Akbar, and La ilaha illallah. The Prophet (PBUH) said these are the most beloved words to Allah.",
    angels: "Angels are creations of Allah made from light. Key angels include: Jibreel (revelation), Mikaeel (sustenance), Israfeel (Trumpet), Azrael (death), Munkar & Nakir (grave questioning), and the two recording angels.",
    jannah: "Jannah (Paradise) is the eternal abode of bliss. The highest level is Firdaus al-A'la. It contains what 'no eye has seen, no ear has heard, and no mind has imagined.' Every person in Jannah will be 33 years old with no sickness or sorrow.",
    paradise: "Jannah (Paradise) is the eternal abode of bliss. The highest level is Firdaus al-A'la. It contains what 'no eye has seen, no ear has heard, and no mind has imagined.' Every person in Jannah will be 33 years old with no sickness or sorrow.",
    grave: "After death, the soul enters Barzakh — the intermediate state. Two angels (Munkar and Nakir) question the deceased about their Lord, religion, and Prophet. The grave is either a garden of Paradise or a pit of Hellfire.",
    judgment: "Yawm al-Qiyamah is when all humanity will be resurrected. Major signs include: the Mahdi, Dajjal, descent of Isa (AS), Yajuj & Majuj, the Beast, and the sun rising from the west. Deeds will be weighed on the Mizan (scales).",
    caliph: "The Khulafa al-Rashidun are: Abu Bakr as-Siddiq (2 years), Umar ibn al-Khattab (10 years), Uthman ibn Affan (12 years), and Ali ibn Abi Talib (5 years). They ruled approximately 30 years total according to the Sunnah.",
    companion: "The Sahaba are the best generation. The ten promised Paradise (al-Ashara al-Mubashshara) are: Abu Bakr, Umar, Uthman, Ali, Talhah, Zubayr, Abdur Rahman ibn Awf, Sa'd, Sa'id ibn Zayd, and Abu Ubaydah.",
    manners: "The Prophet (PBUH) said: 'I have been sent to perfect noble character.' (Muwatta). Key manners: greeting with salam, saying Bismillah before eating, honoring parents, being truthful, keeping promises, having patience and gratitude.",
    repentance: "Allah says: 'Say, O My servants who have transgressed against themselves, do not despair of the mercy of Allah. Indeed, Allah forgives all sins.' (39:53). Conditions for tawbah: stop the sin, feel regret, resolve never to return, and restore others' rights.",
    istighfar: "Allah says: 'Say, O My servants who have transgressed against themselves, do not despair of the mercy of Allah. Indeed, Allah forgives all sins.' (39:53). Saying Astaghfirullah 100 times daily is highly recommended.",
    zamzam: "Zamzam water originated when Hajar ran between Safa and Marwah searching for water for baby Ismail. The Prophet (PBUH) said: 'Zamzam water is for whatever purpose it is drunk for.' It has been flowing for over 4,000 years.",
    istikhara: "Istikhara is a prayer for guidance in decisions. Pray 2 Rak'ahs, then make the dua taught by the Prophet (PBUH). Then follow what feels most comfortable in your heart. Allah will guide you to what is best.",
    food: "Haram foods: pork, blood, carrion, alcohol, and improperly slaughtered meat. Halal meat requires: Muslim/Christian/Jewish slaughterer, Bismillah, sharp instrument, and complete blood drainage.",
    marriage: "Marriage (Nikah) is half of faith. Requirements: consent of both parties, Mahr (dowry), Wali (guardian), two Muslim witnesses, and Khutbah. The Prophet (PBUH) said: 'The best of you is the best to his wife.'",
    patience: "Sabr has three types: patience in worship, patience in avoiding sins, and patience during calamities. The Prophet (PBUH) said: 'How wonderful is the affair of the believer! For all of his affairs are good.' (Muslim)",
    gratitude: "Shukr means using Allah's blessings in obedience to Him. 'If you are grateful, I will surely increase you.' (14:7). The Prophet (PBUH) said a believer's affairs are all good — gratitude in ease, patience in hardship.",
    forgiveness: "The Prophet (PBUH) said: 'The strong man is not the one who can wrestle others down. The strong man is the one who can control himself when he is angry.' (Bukhari). 'Let them pardon and overlook. Would you not like that Allah should forgive you?' (24:22)",
    parents: "Honoring parents is one of the greatest obligations. The Prophet (PBUH) said: 'Paradise lies at the feet of mothers.' (Nasa'i). 'The pleasure of the Lord lies in the pleasure of the parent.' (Tirmidhi)",
    salawat: "Allah says: 'Indeed, Allah and His angels confer blessing upon the Prophet. O you who have believed, ask [Allah to confer] blessing upon him.' (33:56). Sending Salawat earns 10 blessings, erases 10 sins, and raises 10 degrees in Paradise.",
    adhkar: "The Prophet (PBUH) taught specific Adhkar for morning and evening: Ayat al-Kursi, last 3 Surahs (x3), SubhanAllahi wa bihamdihi (100x), and La ilaha illallahu wahdahu (10x). Nothing will harm one who says these.",
    salutation: "Wa alaykumu s-salam wa rahmatullahi wa barakatuh! Peace, mercy, and blessings of Allah be upon you too. How may I assist you with your Islamic knowledge journey today?",
  };

  for (const word of words) {
    const clean = word.replace(/[^a-z]/g, "");
    if (categoryKeywords[clean]) {
      return { response: categoryKeywords[clean], matchedEntry: null };
    }
  }

  return {
    response: "That's a wonderful question! In Islam, seeking knowledge is a noble pursuit. The Prophet (PBUH) said: 'Seeking knowledge is an obligation upon every Muslim.' (Ibn Majah). Could you please provide more details so I can give you a more specific answer? I can help with topics related to Quran, Hadith, Fiqh (prayer, fasting, zakat, hajj), Aqeedah (beliefs), Seerah (Prophet's life), Islamic history, ethics, and daily supplications.",
    matchedEntry: null,
  };
}

export const chatRouter = createRouter({
  send: publicQuery
    .input(z.object({ message: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const result = getAIResponse(input.message);

      // Save messages if user is authenticated
      if (ctx.user) {
        const user = ctx.user;
        const userValues: Record<string, unknown> = {
          role: "user" as const,
          content: input.message,
        };
        const aiValues: Record<string, unknown> = {
          role: "assistant" as const,
          content: result.response,
        };

        if (user.authType === "oauth") {
          userValues.userId = user.id;
          aiValues.userId = user.id;
        } else {
          userValues.localUserId = user.id;
          aiValues.localUserId = user.id;
        }

        await db.insert(chatMessages).values(userValues as typeof chatMessages.$inferInsert);
        await db.insert(chatMessages).values(aiValues as typeof chatMessages.$inferInsert);
      }

      return result;
    }),

  knowledgeStats: publicQuery.query(() => {
    return {
      totalEntries: ISLAMIC_KNOWLEDGE.length,
      categories: Object.entries(CATEGORY_COUNTS).map(([category, count]) => ({
        category,
        count,
        name: category.charAt(0).toUpperCase() + category.slice(1),
      })),
    };
  }),

  history: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const user = ctx.user!;

    if (user.authType === "oauth") {
      return db.query.chatMessages.findMany({
        where: eq(chatMessages.userId, user.id),
        orderBy: [desc(chatMessages.createdAt)],
        limit: 50,
      });
    } else {
      return db.query.chatMessages.findMany({
        where: eq(chatMessages.localUserId, user.id),
        orderBy: [desc(chatMessages.createdAt)],
        limit: 50,
      });
    }
  }),

  clear: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    const user = ctx.user!;

    if (user.authType === "oauth") {
      await db.delete(chatMessages).where(eq(chatMessages.userId, user.id));
    } else {
      await db.delete(chatMessages).where(eq(chatMessages.localUserId, user.id));
    }

    return { success: true };
  }),
});
