import { z } from "zod";
import { createRouter, authedQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { quizResults } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const quizRouter = createRouter({
  submit: authedQuery
    .input(
      z.object({
        category: z.string(),
        score: z.number(),
        totalQuestions: z.number(),
        answers: z.any().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const user = ctx.user!;

      const values: Record<string, unknown> = {
        category: input.category,
        score: input.score,
        totalQuestions: input.totalQuestions,
        answers: input.answers,
      };

      if (user.authType === "oauth") {
        values.userId = user.id;
      } else {
        values.localUserId = user.id;
      }

      const result = await db.insert(quizResults).values(values as typeof quizResults.$inferInsert);
      return { id: Number(result[0].insertId) };
    }),

  history: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const user = ctx.user!;

    if (user.authType === "oauth") {
      return db.query.quizResults.findMany({
        where: eq(quizResults.userId, user.id),
        orderBy: [desc(quizResults.createdAt)],
      });
    } else {
      return db.query.quizResults.findMany({
        where: eq(quizResults.localUserId, user.id),
        orderBy: [desc(quizResults.createdAt)],
      });
    }
  }),

  leaderboard: publicQuery.query(async () => {
    const db = getDb();
    return db.query.quizResults.findMany({
      orderBy: [desc(quizResults.score)],
      limit: 10,
    });
  }),
});
