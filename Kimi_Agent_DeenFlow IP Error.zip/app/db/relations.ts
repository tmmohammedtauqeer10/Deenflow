import { relations } from "drizzle-orm";
import { users, localUsers, bookmarks, quizResults, chatMessages } from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  bookmarks: many(bookmarks),
  quizResults: many(quizResults),
  chatMessages: many(chatMessages),
}));

export const localUsersRelations = relations(localUsers, ({ many }) => ({
  bookmarks: many(bookmarks),
  quizResults: many(quizResults),
  chatMessages: many(chatMessages),
}));

export const bookmarksRelations = relations(bookmarks, ({ one }) => ({
  user: one(users, { fields: [bookmarks.userId], references: [users.id] }),
  localUser: one(localUsers, { fields: [bookmarks.localUserId], references: [localUsers.id] }),
}));

export const quizResultsRelations = relations(quizResults, ({ one }) => ({
  user: one(users, { fields: [quizResults.userId], references: [users.id] }),
  localUser: one(localUsers, { fields: [quizResults.localUserId], references: [localUsers.id] }),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  user: one(users, { fields: [chatMessages.userId], references: [users.id] }),
  localUser: one(localUsers, { fields: [chatMessages.localUserId], references: [localUsers.id] }),
}));
