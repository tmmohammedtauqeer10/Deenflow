export interface LibraryBook {
  id: string;
  title: string;
  author: string;
  language: string;
  pages: number;
  badge: string;
  cover_color: string;
  cover_url: string;
  cover_fallback: string;
  pdf_url: string;
}

export interface LibraryCategory {
  category_id: string;
  category_name: string;
  icon: string;
  color: string;
  books: LibraryBook[];
}

export interface LibraryApi {
  api_version: string;
  last_updated: string;
  app_name: string;
  total_categories: number;
  cdn: string;
  categories: LibraryCategory[];
}

export interface QuizQuestion {
  question_id: string;
  text: string;
  options: string[];
  correct_index: number;
}

export interface QuizCategory {
  category_id: string;
  category_name: string;
  difficulty: string;
  points_per_question: number;
  questions: QuizQuestion[];
}

export interface QuizApi {
  status: string;
  api_version: string;
  last_updated: string;
  total_categories: number;
  categories: QuizCategory[];
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}
