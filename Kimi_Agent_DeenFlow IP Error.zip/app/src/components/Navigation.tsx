import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import {
  BookOpen, Brain, MessageSquare, Mail, Menu, X,
  Star, Clock, ScrollText, Sparkles, Calendar, BookMarked,
  Home, LogIn, LayoutDashboard,
} from "lucide-react";

const navLinks = [
  { path: "/", label: "Home", icon: <Home className="w-3.5 h-3.5" /> },
  { path: "/quran", label: "Quran", icon: <BookOpen className="w-3.5 h-3.5" /> },
  { path: "/prayer", label: "Prayer", icon: <Clock className="w-3.5 h-3.5" /> },
  { path: "/hadith", label: "Hadith", icon: <ScrollText className="w-3.5 h-3.5" /> },
  { path: "/names", label: "99 Names", icon: <Sparkles className="w-3.5 h-3.5" /> },
  { path: "/calendar", label: "Calendar", icon: <Calendar className="w-3.5 h-3.5" /> },
  { path: "/library", label: "Library", icon: <BookMarked className="w-3.5 h-3.5" /> },
  { path: "/quiz", label: "Quiz", icon: <Brain className="w-3.5 h-3.5" /> },
  { path: "/chat", label: "Ask AI", icon: <MessageSquare className="w-3.5 h-3.5" /> },
  { path: "/contact", label: "Contact", icon: <Mail className="w-3.5 h-3.5" /> },
];

export default function Navigation() {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[rgba(10,22,40,0.95)] backdrop-blur-xl border-b border-[rgba(26,147,111,0.15)]"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 text-[#e8dcc8] no-underline shrink-0">
          <Star className="w-5 h-5 text-[#1a936f]" />
          <span className="font-display text-xl">DeenFlow</span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden xl:flex items-center gap-0.5">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-[11px] uppercase tracking-[0.07em] transition-all duration-300 whitespace-nowrap ${
                isActive(link.path)
                  ? "text-[#1a936f] bg-[rgba(26,147,111,0.1)]"
                  : "text-[#8b9db8] hover:text-[#1a936f] hover:bg-[rgba(26,147,111,0.06)]"
              }`}
            >
              {link.icon}
              {link.label}
            </Link>
          ))}

          {isAdmin && (
            <Link
              to="/admin"
              className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-[11px] uppercase tracking-[0.07em] transition-all duration-300 whitespace-nowrap ${
                isActive("/admin")
                  ? "text-[#c9a66b] bg-[rgba(201,166,107,0.1)]"
                  : "text-[#c9a66b] hover:text-[#1a936f] hover:bg-[rgba(26,147,111,0.06)]"
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              Admin
            </Link>
          )}

          {isAuthenticated ? (
            <div className="flex items-center gap-2 ml-2 pl-2 border-l border-[rgba(139,157,184,0.15)]">
              <span className="text-[11px] text-[#8b9db8] max-w-[80px] truncate">{user?.name}</span>
              <button
                onClick={logout}
                className="text-[11px] uppercase tracking-[0.07em] border border-[rgba(139,157,184,0.2)] text-[#8b9db8] px-3 py-1.5 rounded-full hover:border-[#c53030] hover:text-[#c53030] transition-all duration-300"
              >
                Logout
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="ml-2 flex items-center gap-1 text-[11px] uppercase tracking-[0.07em] border border-[#1a936f] text-[#1a936f] px-3 py-1.5 rounded-full hover:bg-[rgba(26,147,111,0.1)] transition-all duration-300"
            >
              <LogIn className="w-3 h-3" /> Sign In
            </Link>
          )}
        </div>

        {/* Mobile menu button */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="xl:hidden text-[#e8dcc8] p-2"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="xl:hidden bg-[rgba(10,22,40,0.98)] backdrop-blur-xl border-t border-[rgba(26,147,111,0.15)] px-4 py-4 flex flex-col gap-0.5 max-h-[80vh] overflow-y-auto">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`flex items-center gap-2 text-sm py-2.5 px-3 rounded-lg transition-all duration-200 ${
                isActive(link.path)
                  ? "text-[#1a936f] bg-[rgba(26,147,111,0.1)]"
                  : "text-[#8b9db8] hover:text-[#1a936f] hover:bg-[rgba(26,147,111,0.06)]"
              }`}
            >
              {link.icon}
              {link.label}
            </Link>
          ))}
          {isAdmin && (
            <Link
              to="/admin"
              className={`flex items-center gap-2 text-sm py-2.5 px-3 rounded-lg transition-all duration-200 ${
                isActive("/admin")
                  ? "text-[#c9a66b] bg-[rgba(201,166,107,0.1)]"
                  : "text-[#c9a66b] hover:text-[#1a936f] hover:bg-[rgba(26,147,111,0.06)]"
              }`}
            >
              <LayoutDashboard className="w-4 h-4" /> Admin
            </Link>
          )}
          {isAuthenticated ? (
            <button
              onClick={logout}
              className="flex items-center gap-2 text-sm text-[#c53030] py-2.5 px-3 mt-1 border-t border-[rgba(139,157,184,0.1)]"
            >
              <LogIn className="w-4 h-4" /> Logout ({user?.name})
            </button>
          ) : (
            <Link
              to="/login"
              className="flex items-center gap-2 text-sm text-[#1a936f] py-2.5 px-3 mt-1 border-t border-[rgba(139,157,184,0.1)]"
            >
              <LogIn className="w-4 h-4" /> Sign In
            </Link>
          )}
        </div>
      )}
    </nav>
  );
}
