// ============================================================
// DEENFLOW ISLAMIC APIs - All Free, Real Islamic Content APIs
// ============================================================

// ---------- 1. AL-QURAN CLOUD API ----------
// https://alquran.cloud/api - Free Quran text, audio, translations
const QURAN_API = "https://api.alquran.cloud/v1";

export interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
}

export interface Ayah {
  number: number;
  text: string;
  numberInSurah: number;
  audio: string;
  audioSecondary: string[];
}

export async function getAllSurahs(): Promise<Surah[]> {
  const data = await fetchWithCache<any>(`${QURAN_API}/surah`, "surah_list");
  return data.data;
}

export async function getSurah(surahNumber: number, edition = "quran-uthmani"): Promise<{ surah: Surah; ayahs: Ayah[] }> {
  const data = await fetchWithCache<any>(`${QURAN_API}/surah/${surahNumber}/${edition}`, `surah_${surahNumber}_${edition}`);
  return { surah: data.data, ayahs: data.data.ayahs };
}

export async function getAyah(surah: number, ayah: number, edition = "en.sahih"): Promise<Ayah> {
  const res = await fetch(`${QURAN_API}/ayah/${surah}:${ayah}/${edition}`);
  const data = await res.json();
  return data.data;
}

export async function searchQuran(query: string, language = "en"): Promise<any[]> {
  const data = await fetchWithCache<any>(`${QURAN_API}/search/${encodeURIComponent(query)}/all/${language}`, `search_${query}_${language}`);
  return data.data?.matches || [];
}

// Audio recitation editions
export const AUDIO_EDITIONS = [
  { identifier: "ar.alafasy", name: "Mishary Rashid Alafasy" },
  { identifier: "ar.abdulbasitmurattal", name: "Abdul Basit Murattal" },
  { identifier: "ar.husary", name: "Mahmoud Khalil Al-Husary" },
  { identifier: "ar.minshawi", name: "Mohamed Siddiq El-Minshawi" },
  { identifier: "ar.ahmedajamy", name: "Ahmed ibn Ali al-Ajamy" },
];

// Translation editions
export const TRANSLATION_EDITIONS = [
  { identifier: "en.sahih", name: "English - Sahih International" },
  { identifier: "en.pickthall", name: "English - Pickthall" },
  { identifier: "en.yusufali", name: "English - Yusuf Ali" },
  { identifier: "ur.ahmedali", name: "Urdu - Kanzul Iman (Ahmad Raza Khan)" },
  { identifier: "ur.junagarhi", name: "Urdu - Muhammad Junagarhi" },
  { identifier: "fr.hamidullah", name: "French - Hamidullah" },
];

// Language groups for filtering
export const LANGUAGE_GROUPS = [
  { code: "en", name: "English" },
  { code: "ur", name: "Urdu" },
  { code: "fr", name: "French" },
  { code: "ar", name: "Arabic" },
];

// ---------- 2. AL-ADHAN PRAYER TIMES API ----------
// https://aladhan.com/prayer-times-api - Free prayer times, Hijri, Qibla, 99 Names
const ADHAN_API = "https://api.aladhan.com/v1";

export interface PrayerTimes {
  Fajr: string;
  Sunrise: string;
  Dhuhr: string;
  Asr: string;
  Maghrib: string;
  Isha: string;
  Imsak: string;
  Midnight: string;
}

export interface PrayerMeta {
  latitude: number;
  longitude: number;
  timezone: string;
  method: { id: number; name: string };
}

export async function getPrayerTimesByCity(
  city: string,
  country: string,
  method = 2
): Promise<{ timings: PrayerTimes; date: any; meta: PrayerMeta }> {
  const data = await fetchWithCache<any>(
    `${ADHAN_API}/timingsByCity?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&method=${method}`,
    `prayer_${city}_${country}_${method}`
  );
  return { timings: data.data.timings, date: data.data.date, meta: data.data.meta };
}

export async function getPrayerTimesByCoords(
  lat: number,
  lng: number,
  method = 2
): Promise<{ timings: PrayerTimes; date: any; meta: PrayerMeta }> {
  const data = await fetchWithCache<any>(
    `${ADHAN_API}/timings?latitude=${lat}&longitude=${lng}&method=${method}`,
    `prayer_coords_${lat.toFixed(2)}_${lng.toFixed(2)}_${method}`
  );
  return { timings: data.data.timings, date: data.data.date, meta: data.data.meta };
}

export async function getPrayerMethods(): Promise<any[]> {
  const data = await fetchWithCache<any>(`${ADHAN_API}/methods`, "prayer_methods");
  return Object.entries(data.data).map(([id, m]: [string, any]) => ({ id: Number(id), ...m }));
}

// ---------- 3. 99 NAMES OF ALLAH API ----------
export interface NameOfAllah {
  name: string;
  transliteration: string;
  number: number;
  en: { meaning: string };
}

export async function get99Names(): Promise<NameOfAllah[]> {
  const data = await fetchWithCache<any>(`${ADHAN_API}/asmaAlHusna`, "99names");
  return data.data;
}

// ---------- 4. HIJRI CALENDAR API ----------
export interface HijriDate {
  day: string;
  month: { number: number; en: string; ar: string };
  year: string;
  weekday: { en: string; ar: string };
}

export async function gregorianToHijri(date: string): Promise<HijriDate> {
  const data = await fetchWithCache<any>(`${ADHAN_API}/gToH?date=${date}`, `hijri_${date}`);
  return data.data.hijri;
}

export async function hijriToGregorian(hijriDate: string): Promise<any> {
  const data = await fetchWithCache<any>(`${ADHAN_API}/hToG?date=${hijriDate}`, `gregorian_${hijriDate}`);
  return data.data.gregorian;
}

export async function getHijriCalendar(year: number, month: number): Promise<any[]> {
  const data = await fetchWithCache<any>(`${ADHAN_API}/hijriCalendar/${year}/${month}`, `hijri_cal_${year}_${month}`);
  return data.data;
}

// ---------- 5. QIBLA DIRECTION API ----------
export async function getQiblaDirection(lat: number, lng: number): Promise<number> {
  const data = await fetchWithCache<any>(`${ADHAN_API}/qibla/${lat}/${lng}`, `qibla_${lat.toFixed(2)}_${lng.toFixed(2)}`);
  return data.data.direction;
}

// ---------- 6. HADITH API (hadithapi.pages.dev) ----------
// Free, no auth required - 22,000+ hadiths from 5 authentic collections
const HADITH_API = "https://hadithapi.pages.dev/api";

export interface Hadith {
  id: number;
  hadithNumber: string;
  arabic: string;
  hadith_english: string;
  narrator: string;
  bookName: string;
  chapter: string;
  chapterNumber: string;
  book: string;
  grade?: string;
  reference?: string;
}

export const HADITH_COLLECTIONS = [
  { key: "bukhari", name: "Sahih Bukhari", count: 7563 },
  { key: "muslim", name: "Sahih Muslim", count: 3032 },
  { key: "abudawud", name: "Sunan Abu Dawud", count: 3998 },
  { key: "tirmidhi", name: "Jami at-Tirmidhi", count: 3956 },
  { key: "ibnmajah", name: "Sunan Ibn Majah", count: 4342 },
] as const;

export async function getHadith(collection: string, id: number): Promise<Hadith> {
  const data = await fetchWithCache<any>(`${HADITH_API}/${collection}/${id}`, `hadith_${collection}_${id}`);
  return data;
}

export async function getRandomHadith(): Promise<Hadith> {
  // Random hadith - skip cache
  const res = await fetch(`${HADITH_API}/random`);
  return res.json();
}

export async function searchHadith(query: string): Promise<Hadith[]> {
  const data = await fetchWithCache<any>(`${HADITH_API}/search?q=${encodeURIComponent(query)}`, `hadith_search_${query}`);
  return data.results || [];
}

// ---------- 7. DAILY HADITH / RANDOM ----------
export async function getDailyHadith(): Promise<Hadith> {
  return getRandomHadith();
}

// ---------- 8. COMPLETE QURAN CDN (fawazahmed0) ----------
// 440+ translations, blazing fast via jsDelivr CDN
export async function getQuranTranslation(edition: string): Promise<any> {
  const res = await fetch(`https://cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/editions/${edition}.json`);
  return res.json();
}

// ============================================================
// LOCAL CACHE / JSON FALLBACK SYSTEM (SQLite-like via localStorage)
// ============================================================

const CACHE_PREFIX = "deenflow_cache_";
const CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

function cacheKey(key: string): string { return `${CACHE_PREFIX}${key}`; }

function getCached<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(cacheKey(key));
    if (!raw) return null;
    const entry = JSON.parse(raw);
    if (Date.now() - entry.ts > CACHE_TTL_MS) {
      localStorage.removeItem(cacheKey(key));
      return null;
    }
    return entry.data as T;
  } catch { return null; }
}

function setCached<T>(key: string, data: T): void {
  try {
    localStorage.setItem(cacheKey(key), JSON.stringify({ ts: Date.now(), data }));
  } catch { /* storage full */ }
}

// Wrapped fetch with cache fallback
async function fetchWithCache<T>(url: string, cacheKeyStr: string): Promise<T> {
  // Try cache first
  const cached = getCached<T>(cacheKeyStr);
  if (cached) return cached;

  // Fetch from network
  const res = await fetch(url);
  const data = await res.json();

  // Cache successful response
  if (data.code === 200 || data.status === "success") {
    setCached(cacheKeyStr, data);
  }
  return data;
}

// ---------- Utility: Geolocation ----------
export function getUserLocation(): Promise<{ lat: number; lng: number }> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation not supported"));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      (err) => reject(err),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  });
}
