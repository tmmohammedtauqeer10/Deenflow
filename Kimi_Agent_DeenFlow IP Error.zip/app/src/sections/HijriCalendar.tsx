import { useState, useEffect } from "react";
import { Calendar, ArrowRightLeft, Loader2, Moon } from "lucide-react";
import { gregorianToHijri, hijriToGregorian, type HijriDate } from "@/lib/islamic-apis";

const HIJRI_MONTHS = [
  "", "Muharram", "Safar", "Rabi' al-awwal", "Rabi' al-thani",
  "Jumada al-awwal", "Jumada al-thani", "Rajab", "Sha'ban",
  "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah",
];

export default function HijriCalendar() {
  const [gDate, setGDate] = useState("");
  const [hDate, setHDate] = useState<HijriDate | null>(null);
  const [hDay, setHDay] = useState("");
  const [hMonth, setHMonth] = useState("");
  const [hYear, setHYear] = useState("");
  const [convertedGregorian, setConvertedGregorian] = useState<any>(null);
  const [loading1, setLoading1] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const [todayHijri, setTodayHijri] = useState<HijriDate | null>(null);

  useEffect(() => {
    // Set default date to today
    const today = new Date();
    const dateStr = `${String(today.getDate()).padStart(2, "0")}-${String(today.getMonth() + 1).padStart(2, "0")}-${today.getFullYear()}`;
    setGDate(dateStr);
    handleGregToHijri(dateStr);

    // Also load today's Hijri date
    gregorianToHijri(dateStr).then(setTodayHijri).catch(() => {});
  }, []);

  const handleGregToHijri = async (dateStr?: string) => {
    const d = dateStr || gDate;
    if (!d) return;
    setLoading1(true);
    try {
      const result = await gregorianToHijri(d);
      setHDate(result);
    } catch { /* ignore */ }
    setLoading1(false);
  };

  const handleHijriToGreg = async () => {
    if (!hDay || !hMonth || !hYear) return;
    setLoading2(true);
    try {
      const hijriStr = `${String(hDay).padStart(2, "0")}-${String(hMonth).padStart(2, "0")}-${hYear}`;
      const result = await hijriToGregorian(hijriStr);
      setConvertedGregorian(result);
    } catch { /* ignore */ }
    setLoading2(false);
  };

  return (
    <section id="calendar" className="w-full bg-[#0a1628] py-24 md:py-32">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-10">
          <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#1a936f]">
            ISLAMIC CALENDAR
          </span>
          <h2 className="font-display text-4xl md:text-5xl text-[#e8dcc8] mt-3">
            Hijri Date Converter
          </h2>
          <p className="text-base text-[#8b9db8] mt-4 max-w-[600px] font-light">
            Convert between Gregorian and Hijri dates. The Islamic calendar is based on lunar cycles and is used to determine Islamic holidays and observances.
          </p>
        </div>

        {/* Today's Hijri Date */}
        {todayHijri && (
          <div className="mb-8 p-5 rounded-xl bg-[rgba(26,147,111,0.06)] border border-[rgba(26,147,111,0.1)] flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[rgba(26,147,111,0.12)] flex items-center justify-center">
              <Moon className="w-6 h-6 text-[#1a936f]" />
            </div>
            <div>
              <p className="text-xs text-[#1a936f] uppercase tracking-wider">Today&apos;s Hijri Date</p>
              <p className="text-lg font-display text-[#e8dcc8]">
                {todayHijri.weekday.en}, {todayHijri.day} {todayHijri.month.en} {todayHijri.year} AH
              </p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Gregorian to Hijri */}
          <div className="p-6 rounded-xl bg-[#0d1f3c] border border-[rgba(26,147,111,0.08)]">
            <div className="flex items-center gap-2 mb-5">
              <Calendar className="w-4 h-4 text-[#1a936f]" />
              <h3 className="text-sm font-medium text-[#e8dcc8]">Gregorian to Hijri</h3>
            </div>

            <div className="flex gap-3 mb-4">
              <input
                type="text"
                value={gDate}
                onChange={(e) => setGDate(e.target.value)}
                placeholder="DD-MM-YYYY"
                className="flex-1 bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-lg px-4 py-2.5 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)]"
              />
              <button
                onClick={() => handleGregToHijri()}
                disabled={loading1}
                className="bg-[#1a936f] text-[#0a1628] rounded-lg px-4 py-2.5 text-sm font-medium hover:bg-[#22b382] disabled:opacity-60 transition-all duration-300"
              >
                {loading1 ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRightLeft className="w-4 h-4" />}
              </button>
            </div>

            {hDate && (
              <div className="p-4 rounded-lg bg-[#0a1628] border border-[rgba(26,147,111,0.08)]">
                <p className="text-xs text-[#8b9db8] mb-1">Hijri Date</p>
                <p className="text-xl font-display text-[#e8dcc8]">
                  {hDate.day} {hDate.month.en} {hDate.year} AH
                </p>
                <p className="text-sm text-[#c9a66b] mt-1" dir="rtl">
                  {hDate.weekday.ar}، {hDate.day} {hDate.month.ar} {hDate.year}
                </p>
              </div>
            )}
          </div>

          {/* Hijri to Gregorian */}
          <div className="p-6 rounded-xl bg-[#0d1f3c] border border-[rgba(26,147,111,0.08)]">
            <div className="flex items-center gap-2 mb-5">
              <Moon className="w-4 h-4 text-[#c9a66b]" />
              <h3 className="text-sm font-medium text-[#e8dcc8]">Hijri to Gregorian</h3>
            </div>

            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={hDay}
                onChange={(e) => setHDay(e.target.value)}
                placeholder="DD"
                className="w-16 bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-lg px-3 py-2.5 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)] text-center"
              />
              <select
                value={hMonth}
                onChange={(e) => setHMonth(e.target.value)}
                className="flex-1 bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-lg px-3 py-2.5 text-sm text-[#e8dcc8] focus:outline-none focus:border-[rgba(26,147,111,0.4)]"
              >
                <option value="">Month</option>
                {HIJRI_MONTHS.map((m, i) => m && (
                  <option key={i} value={String(i).padStart(2, "0")}>{m}</option>
                ))}
              </select>
              <input
                type="text"
                value={hYear}
                onChange={(e) => setHYear(e.target.value)}
                placeholder="YYYY"
                className="w-20 bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-lg px-3 py-2.5 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)] text-center"
              />
              <button
                onClick={handleHijriToGreg}
                disabled={loading2}
                className="bg-[#c9a66b] text-[#0a1628] rounded-lg px-4 py-2.5 text-sm font-medium hover:bg-[#d4b06f] disabled:opacity-60 transition-all duration-300"
              >
                {loading2 ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRightLeft className="w-4 h-4" />}
              </button>
            </div>

            {convertedGregorian && (
              <div className="p-4 rounded-lg bg-[#0a1628] border border-[rgba(201,166,107,0.08)]">
                <p className="text-xs text-[#8b9db8] mb-1">Gregorian Date</p>
                <p className="text-xl font-display text-[#e8dcc8]">
                  {convertedGregorian.date}
                </p>
                <p className="text-sm text-[#c9a66b] mt-1">
                  {convertedGregorian.weekday?.en || ""}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Hijri Month Reference */}
        <div className="mt-10">
          <h3 className="text-sm font-medium text-[#e8dcc8] mb-4">Hijri Months</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
            {HIJRI_MONTHS.filter(Boolean).map((month, i) => (
              <div
                key={i}
                className="p-3 rounded-lg bg-[#0d1f3c] border border-[rgba(26,147,111,0.05)] text-center"
              >
                <p className="text-xs text-[#5a6f85]">{i + 1}</p>
                <p className="text-sm text-[#e8dcc8] mt-0.5">{month}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
