import { useState } from "react";
import { Send, CheckCircle, Loader2 } from "lucide-react";
import { trpc } from "@/providers/trpc";

export default function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const submitContact = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setName("");
      setEmail("");
      setMessage("");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;
    submitContact.mutate({ name, email, message });
  };

  return (
    <section id="contact" className="w-full bg-[#0d1f3c] py-24 md:py-32">
      <div className="max-w-[600px] mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#1a936f]">
            CONNECT
          </span>
          <h2 className="font-display text-4xl md:text-5xl text-[#e8dcc8] mt-3">
            Get in Touch
          </h2>
          <p className="text-base text-[#8b9db8] mt-4 font-light">
            Have suggestions, questions, or want to contribute to the library? We'd love to hear from you.
          </p>
        </div>

        {submitted ? (
          <div className="text-center py-10">
            <CheckCircle className="w-12 h-12 text-[#1a936f] mx-auto mb-4" />
            <p className="text-base text-[#e8dcc8]">
              Message sent successfully! JazakAllah Khair.
            </p>
            <button
              onClick={() => setSubmitted(false)}
              className="mt-4 text-sm text-[#1a936f] hover:underline"
            >
              Send another message
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your Name"
              required
              className="bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-xl px-5 py-3.5 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)] transition-colors duration-300"
            />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your Email"
              required
              className="bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-xl px-5 py-3.5 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)] transition-colors duration-300"
            />
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Your Message"
              required
              rows={5}
              className="bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-xl px-5 py-3.5 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)] transition-colors duration-300 resize-none"
            />
            <button
              type="submit"
              disabled={submitContact.isPending}
              className="w-full bg-[#1a936f] text-[#0a1628] rounded-full py-3.5 text-sm font-medium hover:bg-[#22b382] disabled:opacity-60 transition-all duration-300 flex items-center justify-center gap-2"
            >
              {submitContact.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
              Send Message
            </button>
          </form>
        )}
      </div>
    </section>
  );
}
