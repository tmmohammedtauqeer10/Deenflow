import { Star, Github, Twitter, Heart } from "lucide-react";
import { Link } from "react-router";

export default function Footer() {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="w-full bg-[#0a1628] border-t border-[rgba(26,147,111,0.1)]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-14">
        {/* Top row */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-2 text-[#e8dcc8] no-underline">
            <Star className="w-5 h-5 text-[#1a936f]" />
            <span className="font-display text-xl">DeenFlow</span>
          </Link>
          <div className="flex items-center gap-4">
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#8b9db8] hover:text-[#1a936f] transition-colors duration-300"
            >
              <Github className="w-5 h-5" />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#8b9db8] hover:text-[#1a936f] transition-colors duration-300"
            >
              <Twitter className="w-5 h-5" />
            </a>
          </div>
        </div>

        {/* Middle row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 mt-8">
          <div>
            <h4 className="text-sm font-medium text-[#e8dcc8] mb-3">Platform</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => scrollToSection("library")}
                  className="text-sm text-[#8b9db8] hover:text-[#e8dcc8] transition-colors duration-300"
                >
                  Library
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("quiz")}
                  className="text-sm text-[#8b9db8] hover:text-[#e8dcc8] transition-colors duration-300"
                >
                  Quiz
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("chat")}
                  className="text-sm text-[#8b9db8] hover:text-[#e8dcc8] transition-colors duration-300"
                >
                  Ask AI
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("library")}
                  className="text-sm text-[#8b9db8] hover:text-[#e8dcc8] transition-colors duration-300"
                >
                  Bookmarks
                </button>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-medium text-[#e8dcc8] mb-3">Resources</h4>
            <ul className="space-y-2">
              <li>
                <span className="text-sm text-[#8b9db8] cursor-default">API Docs</span>
              </li>
              <li>
                <a
                  href="https://github.com/tmmohammedtauqeer10/Deenflow"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-[#8b9db8] hover:text-[#e8dcc8] transition-colors duration-300"
                >
                  Open Source
                </a>
              </li>
              <li>
                <span className="text-sm text-[#8b9db8] cursor-default">Contribute</span>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-medium text-[#e8dcc8] mb-3">Legal</h4>
            <ul className="space-y-2">
              <li>
                <span className="text-sm text-[#8b9db8] cursor-default">Privacy Policy</span>
              </li>
              <li>
                <span className="text-sm text-[#8b9db8] cursor-default">Terms of Service</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom row */}
        <div className="mt-12 pt-6 border-t border-[rgba(26,147,111,0.08)] flex items-center justify-center gap-1 text-xs text-[#5a6f85]">
          &copy; {new Date().getFullYear()} DeenFlow AI. Built with <Heart className="w-3 h-3 text-[#c53030] mx-0.5" /> for the Ummah.
        </div>
      </div>
    </footer>
  );
}
