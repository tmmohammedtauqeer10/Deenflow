import { useState, useRef, useEffect } from "react";
import { Send, Sparkles, User, Diamond, Loader2 } from "lucide-react";
import { trpc } from "@/providers/trpc";
import type { ChatMessage } from "@/types/api";

export default function Chat() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content:
        "As-salamu alaykum! I am your Islamic knowledge assistant. Ask me anything about Quran, Hadith, Fiqh, Seerah, or Islamic history.",
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const sendMessage = trpc.chat.send.useMutation({
    onSuccess: (data) => {
      setMessages((prev) => [...prev, { role: "assistant", content: data.response }]);
      setIsTyping(false);
    },
    onError: () => {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "I apologize, but I'm having trouble processing your request. Please try again.",
        },
      ]);
      setIsTyping(false);
    },
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!input.trim() || isTyping) return;

    const userMessage = input.trim();
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setInput("");
    setIsTyping(true);
    sendMessage.mutate({ message: userMessage });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <section id="chat" className="w-full bg-[#0a1628] py-24 md:py-32">
      <div className="max-w-[900px] mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#1a936f]">
            ASK AI
          </span>
          <h2 className="font-display text-4xl md:text-5xl text-[#e8dcc8] mt-3">
            Your Islamic Knowledge Assistant
          </h2>
          <p className="text-base text-[#8b9db8] mt-4 font-light">
            Ask questions about Quran, Hadith, Fiqh, or Islamic history. Our AI provides answers grounded in authentic sources.
          </p>
        </div>

        {/* Chat Interface */}
        <div className="bg-[#0d1f3c] rounded-2xl border border-[rgba(26,147,111,0.15)] flex flex-col" style={{ height: "500px" }}>
          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
              >
                {/* Avatar */}
                <div
                  className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                    msg.role === "assistant"
                      ? "bg-[rgba(26,147,111,0.15)]"
                      : "bg-[rgba(201,166,107,0.15)]"
                  }`}
                >
                  {msg.role === "assistant" ? (
                    <Diamond className="w-4 h-4 text-[#1a936f]" />
                  ) : (
                    <User className="w-4 h-4 text-[#c9a66b]" />
                  )}
                </div>

                {/* Bubble */}
                <div
                  className={`max-w-[80%] px-4 py-3 rounded-xl text-sm leading-relaxed ${
                    msg.role === "assistant"
                      ? "bg-[rgba(26,147,111,0.08)] text-[#e8dcc8] rounded-tl-sm"
                      : "bg-[rgba(201,166,107,0.08)] text-[#e8dcc8] rounded-tr-sm"
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}

            {/* Typing indicator */}
            {isTyping && (
              <div className="flex gap-3">
                <div className="w-9 h-9 rounded-full bg-[rgba(26,147,111,0.15)] flex items-center justify-center shrink-0">
                  <Sparkles className="w-4 h-4 text-[#1a936f]" />
                </div>
                <div className="bg-[rgba(26,147,111,0.08)] px-4 py-3 rounded-xl rounded-tl-sm">
                  <div className="flex gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-[#1a936f] animate-pulse-dot" style={{ animationDelay: "0ms" }} />
                    <span className="w-2 h-2 rounded-full bg-[#1a936f] animate-pulse-dot" style={{ animationDelay: "200ms" }} />
                    <span className="w-2 h-2 rounded-full bg-[#1a936f] animate-pulse-dot" style={{ animationDelay: "400ms" }} />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="border-t border-[rgba(26,147,111,0.1)] px-4 md:px-6 py-4">
            <div className="flex items-center gap-3">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about any Islamic topic..."
                className="flex-1 bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-full px-5 py-3 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)] transition-colors duration-300"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isTyping}
                className="w-10 h-10 rounded-full bg-[#1a936f] flex items-center justify-center hover:bg-[#22b382] disabled:opacity-40 disabled:hover:bg-[#1a936f] transition-all duration-300 shrink-0"
              >
                {isTyping ? (
                  <Loader2 className="w-4 h-4 text-[#0a1628] animate-spin" />
                ) : (
                  <Send className="w-4 h-4 text-[#0a1628]" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
