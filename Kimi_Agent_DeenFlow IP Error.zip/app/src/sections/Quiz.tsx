import { useState, useEffect, useCallback } from "react";
import { Check, X, ArrowRight, RotateCcw, Loader2, Sparkles, Trophy, Brain } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import type { QuizApi, QuizCategory, QuizQuestion } from "@/types/api";

const QUIZ_API = "https://raw.githubusercontent.com/tmmohammedtauqeer10/Deenflow/main/quiz_data.json";

export default function Quiz() {
  const [data, setData] = useState<QuizApi | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<QuizCategory | null>(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<{ qId: string; correct: boolean }[]>([]);
  const [quizComplete, setQuizComplete] = useState(false);

  const { isAuthenticated } = useAuth();
  const submitQuiz = trpc.quiz.submit.useMutation();

  useEffect(() => {
    fetch(QUIZ_API)
      .then((r) => r.json())
      .then((d: QuizApi) => {
        setData(d);
        if (d.categories.length > 0) setActiveCategory(d.categories[0]);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const handleSelect = (idx: number) => {
    if (showResult) return;
    setSelectedAnswer(idx);
    setShowResult(true);

    const question = activeCategory?.questions[currentQ];
    if (!question) return;

    const correct = idx === question.correct_index;
    if (correct) setScore((s) => s + 1);
    setAnswers((prev) => [...prev, { qId: question.question_id, correct }]);
  };

  const handleNext = useCallback(() => {
    if (!activeCategory) return;
    if (currentQ < activeCategory.questions.length - 1) {
      setCurrentQ((q) => q + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setQuizComplete(true);
      if (isAuthenticated) {
        submitQuiz.mutate({
          category: activeCategory.category_name,
          score,
          totalQuestions: activeCategory.questions.length,
          answers,
        });
      }
    }
  }, [activeCategory, currentQ, score, answers, isAuthenticated, submitQuiz]);

  const resetQuiz = () => {
    setCurrentQ(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setAnswers([]);
    setQuizComplete(false);
  };

  const question: QuizQuestion | null = activeCategory?.questions[currentQ] || null;
  const progress = activeCategory ? ((currentQ + (showResult ? 1 : 0)) / activeCategory.questions.length) * 100 : 0;

  return (
    <section id="quiz" className="w-full bg-[#0d1f3c] py-24 md:py-32">
      <div className="max-w-[800px] mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#1a936f]">
            KNOWLEDGE CHECK
          </span>
          <h2 className="font-display text-4xl md:text-5xl text-[#e8dcc8] mt-3">
            Test Your Understanding
          </h2>
          <p className="text-base text-[#8b9db8] mt-4 font-light">
            Challenge yourself with quizzes on Seerah, Quran, Hadith, Fiqh, and Islamic History.
          </p>
        </div>

        {/* Loading */}
        {loading && (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-[#1a936f] animate-spin" />
          </div>
        )}

        {data && (
          <div className="bg-[#0a1628] rounded-2xl border border-[rgba(26,147,111,0.15)] overflow-hidden">
            {/* Progress bar */}
            {!quizComplete && (
              <div className="h-[3px] bg-[rgba(139,157,184,0.1)]">
                <div
                  className="h-full bg-[#1a936f] transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            )}

            <div className="p-6 md:p-10">
              {/* Category selector */}
              {!quizComplete && (
                <div className="flex flex-wrap gap-2 mb-8">
                  {data.categories.map((cat) => (
                    <button
                      key={cat.category_id}
                      onClick={() => {
                        setActiveCategory(cat);
                        resetQuiz();
                      }}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-300 ${
                        activeCategory?.category_id === cat.category_id
                          ? "bg-[rgba(26,147,111,0.15)] text-[#1a936f]"
                          : "border border-[rgba(139,157,184,0.15)] text-[#8b9db8] hover:border-[rgba(26,147,111,0.3)]"
                      }`}
                    >
                      {cat.category_name}
                    </button>
                  ))}
                </div>
              )}

              {quizComplete ? (
                /* Score display */
                <div className="text-center py-10">
                  <Trophy className="w-16 h-16 text-[#c9a66b] mx-auto mb-4" />
                  <div className="font-display text-6xl text-[#c9a66b]">
                    {score}/{activeCategory?.questions.length || 0}
                  </div>
                  <p className="text-lg text-[#8b9db8] mt-4">
                    {score >= 8
                      ? "Excellent! MashaAllah, your knowledge is impressive!"
                      : score >= 5
                      ? "Good effort! Keep learning and growing."
                      : "Keep studying! Every step in seeking knowledge is rewarded."}
                  </p>
                  <button
                    onClick={resetQuiz}
                    className="inline-flex items-center gap-2 mt-6 bg-[#1a936f] text-[#0a1628] rounded-full px-6 py-2.5 text-sm font-medium hover:bg-[#22b382] transition-all duration-300"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Try Again
                  </button>
                </div>
              ) : question ? (
                /* Question */
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Brain className="w-4 h-4 text-[#1a936f]" />
                    <span className="font-mono text-xs text-[#8b9db8]">
                      Question {currentQ + 1} of {activeCategory?.questions.length}
                    </span>
                  </div>
                  <h3 className="text-lg md:text-xl text-[#e8dcc8] font-normal leading-relaxed">
                    {question.text}
                  </h3>

                  {/* Options */}
                  <div className="flex flex-col gap-3 mt-6">
                    {question.options.map((opt, idx) => {
                      const isSelected = selectedAnswer === idx;
                      const isCorrect = idx === question.correct_index;
                      let borderClass = "border-[rgba(139,157,184,0.15)]";
                      let bgClass = "bg-transparent";

                      if (showResult) {
                        if (isCorrect) {
                          borderClass = "border-[#1a936f]";
                          bgClass = "bg-[rgba(26,147,111,0.15)]";
                        } else if (isSelected && !isCorrect) {
                          borderClass = "border-[#c53030]";
                          bgClass = "bg-[rgba(197,48,48,0.08)]";
                        }
                      } else if (isSelected) {
                        borderClass = "border-[#1a936f]";
                        bgClass = "bg-[rgba(26,147,111,0.08)]";
                      }

                      return (
                        <button
                          key={idx}
                          onClick={() => handleSelect(idx)}
                          disabled={showResult}
                          className={`flex items-center gap-3 w-full text-left px-5 py-4 rounded-xl border ${borderClass} ${bgClass} hover:border-[rgba(26,147,111,0.3)] transition-all duration-300`}
                        >
                          <span className="w-7 h-7 rounded-full bg-[rgba(139,157,184,0.1)] flex items-center justify-center text-xs text-[#8b9db8] shrink-0">
                            {String.fromCharCode(65 + idx)}
                          </span>
                          <span className="text-[#e8dcc8] text-sm flex-1">{opt}</span>
                          {showResult && isCorrect && (
                            <Check className="w-5 h-5 text-[#1a936f] shrink-0" />
                          )}
                          {showResult && isSelected && !isCorrect && (
                            <X className="w-5 h-5 text-[#c53030] shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Next button */}
                  {showResult && (
                    <button
                      onClick={handleNext}
                      className="inline-flex items-center gap-2 mt-6 bg-[#1a936f] text-[#0a1628] rounded-full px-6 py-2.5 text-sm font-medium hover:bg-[#22b382] transition-all duration-300"
                    >
                      {currentQ < (activeCategory?.questions.length || 0) - 1 ? (
                        <>
                          Next Question <ArrowRight className="w-4 h-4" />
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          See Results
                        </>
                      )}
                    </button>
                  )}
                </div>
              ) : null}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
