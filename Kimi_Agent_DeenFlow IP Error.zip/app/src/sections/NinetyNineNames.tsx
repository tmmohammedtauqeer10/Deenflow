import { useState, useEffect } from "react";
import { Loader2, Search } from "lucide-react";
import { get99Names, type NameOfAllah } from "@/lib/islamic-apis";

export default function NinetyNineNames() {
  const [names, setNames] = useState<NameOfAllah[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    get99Names()
      .then((data) => {
        setNames(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const filteredNames = names.filter(
    (n) =>
      n.name.includes(searchQuery) ||
      n.transliteration.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.en.meaning.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section id="names" className="w-full bg-[#0d1f3c] py-24 md:py-32">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-10">
          <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#1a936f]">
            ASMA UL HUSNA
          </span>
          <h2 className="font-display text-4xl md:text-5xl text-[#e8dcc8] mt-3">
            99 Names of Allah
          </h2>
          <p className="text-base text-[#8b9db8] mt-4 max-w-[600px] font-light">
            Learn and reflect upon the 99 beautiful names of Allah (SWT). Each name represents a unique attribute of the Divine.
          </p>
        </div>

        {/* Search */}
        <div className="relative max-w-md mb-8">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5a6f85]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, transliteration, or meaning..."
            className="w-full bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-xl pl-11 pr-4 py-3 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)]"
          />
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-[#1a936f] animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {filteredNames.map((name) => (
              <div
                key={name.number}
                className="group p-4 rounded-xl bg-[#0a1628] border border-[rgba(26,147,111,0.06)] hover:border-[rgba(26,147,111,0.25)] hover:bg-[rgba(26,147,111,0.04)] transition-all duration-300 text-center"
              >
                <div className="w-8 h-8 rounded-full bg-[rgba(26,147,111,0.08)] flex items-center justify-center mx-auto mb-2">
                  <span className="text-[10px] font-medium text-[#1a936f]">{name.number}</span>
                </div>
                <p className="text-lg text-[#e8dcc8] font-medium" dir="rtl">{name.name}</p>
                <p className="text-xs text-[#c9a66b] mt-1">{name.transliteration}</p>
                <p className="text-[11px] text-[#8b9db8] mt-1.5 leading-snug">{name.en.meaning}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
