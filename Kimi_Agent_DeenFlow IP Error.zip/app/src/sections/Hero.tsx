import { useEffect, useRef } from "react";
import { ChevronDown } from "lucide-react";

interface HeroProps {
  scrollToSection: (id: string) => void;
}

interface Site {
  x: number;
  y: number;
  baseX: number;
  baseY: number;
}

function generateIslamicSites(width: number, height: number, cols: number, rows: number): Site[] {
  const sites: Site[] = [];
  const cellW = width / cols;
  const cellH = height / rows;
  const avoidanceRadius = 180;
  const cx = width / 2;
  const cy = height / 2;

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const baseX = col * cellW + cellW / 2;
      const baseY = row * cellH + cellH / 2;

      // Skip center zone
      const dCenter = Math.sqrt((baseX - cx) ** 2 + (baseY - cy) ** 2);
      if (dCenter < avoidanceRadius) continue;

      // 8-pointed star: center + 8 points
      sites.push({ x: baseX, y: baseY, baseX, baseY });

      const isStar = (row + col) % 2 === 0;
      const size = Math.min(cellW, cellH) * 0.35;

      if (isStar) {
        // 8-pointed star
        for (let i = 0; i < 8; i++) {
          const angle = Math.PI / 8 + (i * Math.PI) / 4;
          const px = baseX + Math.cos(angle) * size * 0.45;
          const py = baseY + Math.sin(angle) * size * 0.45;
          const dCenter2 = Math.sqrt((px - cx) ** 2 + (py - cy) ** 2);
          if (dCenter2 >= avoidanceRadius * 0.7) {
            sites.push({ x: px, y: py, baseX: px, baseY: py });
          }
        }
        // Edge midpoints
        for (let i = 0; i < 8; i++) {
          const angle1 = Math.PI / 8 + (i * Math.PI) / 4;
          const angle2 = Math.PI / 8 + ((i + 1) * Math.PI) / 4;
          const px = baseX + (Math.cos(angle1) + Math.cos(angle2)) * size * 0.225;
          const py = baseY + (Math.sin(angle1) + Math.sin(angle2)) * size * 0.225;
          const dCenter2 = Math.sqrt((px - cx) ** 2 + (py - cy) ** 2);
          if (dCenter2 >= avoidanceRadius * 0.7) {
            sites.push({ x: px, y: py, baseX: px, baseY: py });
          }
        }
      } else {
        // 6-pointed hexagon
        for (let i = 0; i < 6; i++) {
          const angle = (i * Math.PI) / 3;
          const px = baseX + Math.cos(angle) * size * 0.4;
          const py = baseY + Math.sin(angle) * size * 0.4;
          const dCenter2 = Math.sqrt((px - cx) ** 2 + (py - cy) ** 2);
          if (dCenter2 >= avoidanceRadius * 0.7) {
            sites.push({ x: px, y: py, baseX: px, baseY: py });
          }
        }
        // Hex edge midpoints
        for (let i = 0; i < 6; i++) {
          const angle1 = (i * Math.PI) / 3;
          const angle2 = ((i + 1) * Math.PI) / 3;
          const px = baseX + (Math.cos(angle1) + Math.cos(angle2)) * size * 0.2;
          const py = baseY + (Math.sin(angle1) + Math.sin(angle2)) * size * 0.2;
          const dCenter2 = Math.sqrt((px - cx) ** 2 + (py - cy) ** 2);
          if (dCenter2 >= avoidanceRadius * 0.7) {
            sites.push({ x: px, y: py, baseX: px, baseY: py });
          }
        }
      }
    }
  }

  return sites;
}

function hash(x: number, y: number): number {
  return ((Math.sin(x * 127.1 + y * 311.7) * 43758.5453) % 1 + 1) % 1;
}

export default function Hero({ scrollToSection }: HeroProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sitesRef = useRef<Site[]>([]);
  const mouseRef = useRef({ x: -1000, y: -1000 });
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = window.innerWidth + "px";
      canvas.style.height = window.innerHeight + "px";
      ctx.scale(dpr, dpr);

      const isMobile = window.innerWidth < 768;
      const cols = isMobile ? 3 : 6;
      const rows = isMobile ? 3 : 4;
      sitesRef.current = generateIslamicSites(window.innerWidth, window.innerHeight, cols, rows);
    };

    resize();
    window.addEventListener("resize", resize);

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY };
    };
    window.addEventListener("mousemove", handleMouseMove);

    const draw = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      ctx.clearRect(0, 0, w, h);

      const t = performance.now() / 1000;
      const sites = sitesRef.current;
      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;

      // Mouse repulsion
      for (const site of sites) {
        const dx = site.baseX - mx;
        const dy = site.baseY - my;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 120 && dist > 0) {
          const force = ((120 - dist) / 120) * 15;
          site.x = site.baseX + (dx / dist) * force;
          site.y = site.baseY + (dy / dist) * force;
        } else {
          site.x += (site.baseX - site.x) * 0.05;
          site.y += (site.baseY - site.y) * 0.05;
        }
      }

      // Draw Voronoi-like edges
      ctx.lineWidth = 0.8;
      for (let i = 0; i < sites.length; i++) {
        const s1 = sites[i];
        let nearestDist = Infinity;
        let nearest2Dist = Infinity;
        let nearestSite = sites[0];

        for (let j = 0; j < sites.length; j++) {
          if (i === j) continue;
          const s2 = sites[j];
          const d = Math.sqrt((s1.x - s2.x) ** 2 + (s1.y - s2.y) ** 2);
          if (d < nearestDist) {
            nearest2Dist = nearestDist;
            nearestDist = d;
            nearestSite = s2;
          } else if (d < nearest2Dist) {
            nearest2Dist = d;
          }
        }

        const phase = hash(s1.x, s1.y) * 6.28;
        const pulse = Math.sin(t * 1.5 + phase) * 0.5 + 0.5;
        const glowStrength = 0.3 + pulse * 0.5;

        // Draw cell edges
        const medialAxis = Math.max(0, 1 - (nearest2Dist - nearestDist) / 20);
        const edgeAlpha = Math.max(0, 1 - nearestDist / 80) * (0.3 + medialAxis * 0.7) * glowStrength;

        if (nearestDist < 200) {
          ctx.strokeStyle = `rgba(26, 147, 111, ${edgeAlpha * 0.6})`;
          ctx.beginPath();
          ctx.moveTo(s1.x, s1.y);
          ctx.lineTo(nearestSite.x, nearestSite.y);
          ctx.stroke();

          // Perpendicular bisector line
          const midX = (s1.x + nearestSite.x) / 2;
          const midY = (s1.y + nearestSite.y) / 2;
          const dx = nearestSite.x - s1.x;
          const dy = nearestSite.y - s1.y;
          const len = Math.sqrt(dx * dx + dy * dy);
          if (len > 0) {
            const px = -dy / len * 30;
            const py = dx / len * 30;
            ctx.strokeStyle = `rgba(26, 147, 111, ${edgeAlpha * 0.3})`;
            ctx.beginPath();
            ctx.moveTo(midX - px, midY - py);
            ctx.lineTo(midX + px, midY + py);
            ctx.stroke();
          }
        }

        // Radial glow
        const dist = Math.sqrt((s1.x - w / 2) ** 2 + (s1.y - h / 2) ** 2);
        const glow = Math.exp(-dist * 0.003) * glowStrength;
        const radius = 3 + pulse * 4;

        const grad = ctx.createRadialGradient(s1.x, s1.y, 0, s1.x, s1.y, radius * 3);
        grad.addColorStop(0, `rgba(26, 147, 111, ${glow * 0.15})`);
        grad.addColorStop(1, `rgba(26, 147, 111, 0)`);
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(s1.x, s1.y, radius * 3, 0, Math.PI * 2);
        ctx.fill();

        // Center dot
        ctx.fillStyle = `rgba(26, 147, 111, ${0.4 + pulse * 0.4})`;
        ctx.beginPath();
        ctx.arc(s1.x, s1.y, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }

      rafRef.current = requestAnimationFrame(draw);
    };

    rafRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  return (
    <section className="relative w-full h-screen overflow-hidden">
      {/* Canvas background */}
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          zIndex: 0,
        }}
      />

      {/* Radial gradient overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at 50% 50%, transparent 30%, rgba(10, 22, 40, 0.6) 100%)",
          zIndex: 1,
        }}
      />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-4">
        <span className="font-mono text-[11px] uppercase tracking-[0.15em] text-[#1a936f] mb-5">
          AI-POWERED ISLAMIC KNOWLEDGE
        </span>
        <h1 className="font-display text-5xl sm:text-6xl md:text-7xl text-[#e8dcc8] leading-[1.05]">
          Your Digital
          <br />
          Islamic Companion
        </h1>
        <p className="text-base sm:text-lg text-[#8b9db8] max-w-[560px] mt-6 font-light leading-relaxed">
          Access authentic Quranic commentaries, Hadith collections, Fiqh manuals, and test your knowledge with our AI-powered quiz engine.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 mt-10">
          <button
            onClick={() => scrollToSection("library")}
            className="bg-[#1a936f] text-[#0a1628] rounded-full px-7 py-3 text-sm font-medium hover:bg-[#22b382] hover:scale-[1.02] transition-all duration-300"
          >
            Explore Library
          </button>
          <button
            onClick={() => scrollToSection("quiz")}
            className="bg-transparent border border-[rgba(26,147,111,0.4)] text-[#1a936f] rounded-full px-7 py-3 text-sm font-medium hover:border-[#1a936f] transition-all duration-300"
          >
            Take a Quiz
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
        <ChevronDown className="w-5 h-5 text-[#8b9db8] opacity-50" />
      </div>
    </section>
  );
}
