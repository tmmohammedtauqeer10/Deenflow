import { useState, useEffect } from "react";
import {
  Clock, MapPin, Loader2, Compass, Sunrise, Sun, Sunset, Moon, Navigation,
} from "lucide-react";
import {
  getPrayerTimesByCoords, getPrayerTimesByCity, getPrayerMethods, getQiblaDirection,
  getUserLocation, type PrayerTimes, type PrayerMeta, type HijriDate,
  gregorianToHijri,
} from "@/lib/islamic-apis";

const PRAYER_ICONS: Record<string, React.ReactNode> = {
  Fajr: <Sunrise className="w-5 h-5" />,
  Sunrise: <Sun className="w-5 h-5" />,
  Dhuhr: <Sun className="w-5 h-5" />,
  Asr: <Sunset className="w-5 h-5" />,
  Maghrib: <Sunset className="w-5 h-5" />,
  Isha: <Moon className="w-5 h-5" />,
  Imsak: <Clock className="w-5 h-5" />,
  Midnight: <Moon className="w-5 h-5" />,
};

const PRAYER_NAMES: Record<string, string> = {
  Fajr: "Fajr",
  Sunrise: "Sunrise",
  Dhuhr: "Dhuhr",
  Asr: "Asr",
  Maghrib: "Maghrib",
  Isha: "Isha",
  Imsak: "Imsak",
  Midnight: "Midnight",
};

export default function PrayerTimes() {
  const [times, setTimes] = useState<PrayerTimes | null>(null);
  const [meta, setMeta] = useState<PrayerMeta | null>(null);
  const [hijriDate, setHijriDate] = useState<HijriDate | null>(null);
  const [qibla, setQibla] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [city, setCity] = useState("Mecca");
  const [country, setCountry] = useState("Saudi Arabia");
  const [useLocation, setUseLocation] = useState(false);
  const [methods, setMethods] = useState<any[]>([]);
  const [selectedMethod, setSelectedMethod] = useState(4);
  const [error, setError] = useState("");

  useEffect(() => {
    getPrayerMethods().then(setMethods).catch(() => {});
    loadPrayerTimes();
    loadHijriDate();
  }, []);

  const loadHijriDate = async () => {
    const today = new Date();
    const dateStr = `${String(today.getDate()).padStart(2, "0")}-${String(today.getMonth() + 1).padStart(2, "0")}-${today.getFullYear()}`;
    try {
      const hijri = await gregorianToHijri(dateStr);
      setHijriDate(hijri);
    } catch { /* ignore */ }
  };

  const loadPrayerTimes = async () => {
    setLoading(true);
    setError("");
    try {
      if (useLocation) {
        const { lat, lng } = await getUserLocation();
        const data = await getPrayerTimesByCoords(lat, lng, selectedMethod);
        setTimes(data.timings);
        setMeta(data.meta);
        const qiblaDir = await getQiblaDirection(lat, lng);
        setQibla(qiblaDir);
      } else {
        const data = await getPrayerTimesByCity(city, country, selectedMethod);
        setTimes(data.timings);
        setMeta(data.meta);
      }
    } catch (err: any) {
      setError(err.message || "Failed to load prayer times");
    }
    setLoading(false);
  };

  const handleLocationToggle = () => {
    setUseLocation(!useLocation);
    if (!useLocation) {
      setTimeout(loadPrayerTimes, 100);
    }
  };

  const handleManualSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setUseLocation(false);
    loadPrayerTimes();
  };

  const mainPrayers = ["Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"];

  const now = new Date();
  const currentHour = now.getHours();
  const currentMin = now.getMinutes();
  const currentTime = currentHour * 60 + currentMin;

  const getMinutes = (timeStr: string) => {
    const [h, m] = timeStr.split(":").map(Number);
    return h * 60 + m;
  };

  const nextPrayer = times
    ? mainPrayers.find((p) => getMinutes(times[p as keyof PrayerTimes] as string) > currentTime) || "Fajr"
    : null;

  return (
    <section id="prayer" className="w-full bg-[#0d1f3c] py-24 md:py-32">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-10">
          <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#1a936f]">
            PRAYER TIMES
          </span>
          <h2 className="font-display text-4xl md:text-5xl text-[#e8dcc8] mt-3">
            Salah Times
          </h2>
          <p className="text-base text-[#8b9db8] mt-4 max-w-[600px] font-light">
            Accurate prayer times based on your location. Supports 15+ calculation methods and geolocation.
          </p>
        </div>

        {/* Hijri Date Banner */}
        {hijriDate && (
          <div className="mb-6 p-4 rounded-xl bg-[rgba(26,147,111,0.08)] border border-[rgba(26,147,111,0.12)] text-center">
            <p className="text-sm text-[#1a936f]">
              Today is <span className="font-medium">{hijriDate.weekday.en}</span>,{" "}
              <span className="font-medium">{hijriDate.day} {hijriDate.month.en} {hijriDate.year} AH</span>
            </p>
          </div>
        )}

        {/* Controls */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <button
            onClick={handleLocationToggle}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
              useLocation
                ? "bg-[rgba(26,147,111,0.15)] text-[#1a936f] border border-[rgba(26,147,111,0.3)]"
                : "bg-[#0a1628] border border-[rgba(139,157,184,0.15)] text-[#8b9db8] hover:border-[rgba(26,147,111,0.2)]"
            }`}
          >
            <Navigation className="w-4 h-4" />
            {useLocation ? "Using Your Location" : "Use My Location"}
          </button>

          {!useLocation && (
            <form onSubmit={handleManualSearch} className="flex flex-1 gap-3">
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="City"
                className="flex-1 bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-xl px-4 py-2.5 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)]"
              />
              <input
                type="text"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                placeholder="Country"
                className="flex-1 bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-xl px-4 py-2.5 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)]"
              />
              <button
                type="submit"
                className="bg-[#1a936f] text-[#0a1628] rounded-xl px-5 py-2.5 text-sm font-medium hover:bg-[#22b382] transition-all duration-300"
              >
                Search
              </button>
            </form>
          )}

          <select
            value={selectedMethod}
            onChange={(e) => { setSelectedMethod(Number(e.target.value)); setTimeout(loadPrayerTimes, 100); }}
            className="bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-xl px-4 py-2.5 text-sm text-[#e8dcc8] focus:outline-none focus:border-[rgba(26,147,111,0.4)]"
          >
            {methods.map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </div>

        {meta && (
          <p className="text-xs text-[#5a6f85] mb-6 flex items-center gap-1.5">
            <MapPin className="w-3 h-3" />
            {meta.timezone} &middot; Method: {meta.method.name}
          </p>
        )}

        {/* Prayer Times Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-[#1a936f] animate-spin" />
          </div>
        ) : error ? (
          <div className="text-center py-12 text-[#c53030]">{error}</div>
        ) : times ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {mainPrayers.map((prayer) => (
              <div
                key={prayer}
                className={`p-5 rounded-xl border text-center transition-all duration-300 ${
                  nextPrayer === prayer
                    ? "bg-[rgba(26,147,111,0.12)] border-[rgba(26,147,111,0.3)]"
                    : "bg-[#0a1628] border-[rgba(26,147,111,0.08)]"
                }`}
              >
                <div className={`mx-auto mb-3 ${nextPrayer === prayer ? "text-[#1a936f]" : "text-[#8b9db8]"}`}>
                  {PRAYER_ICONS[prayer]}
                </div>
                <p className="text-xs text-[#8b9db8] uppercase tracking-wider">{PRAYER_NAMES[prayer]}</p>
                <p className={`text-xl font-display mt-1 ${nextPrayer === prayer ? "text-[#1a936f]" : "text-[#e8dcc8]"}`}>
                  {times[prayer as keyof PrayerTimes]}
                </p>
                {nextPrayer === prayer && (
                  <span className="inline-block mt-2 text-[10px] bg-[#1a936f] text-[#0a1628] px-2 py-0.5 rounded-full font-medium">
                    NEXT
                  </span>
                )}
              </div>
            ))}
          </div>
        ) : null}

        {/* Qibla Direction */}
        {qibla !== null && (
          <div className="mt-8 flex items-center justify-center gap-3 p-4 rounded-xl bg-[#0a1628] border border-[rgba(26,147,111,0.08)]">
            <Compass className="w-5 h-5 text-[#c9a66b]" />
            <span className="text-sm text-[#e8dcc8]">
              Qibla Direction: <span className="font-medium text-[#c9a66b]">{qibla.toFixed(1)}&deg;</span> from North
            </span>
          </div>
        )}
      </div>
    </section>
  );
}
