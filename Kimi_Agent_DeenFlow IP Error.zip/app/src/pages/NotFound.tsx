import { Link } from "react-router";
import { Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#0a1628] flex items-center justify-center px-4">
      <div className="text-center">
        <h1 className="font-display text-6xl text-[#1a936f] mb-4">404</h1>
        <p className="text-lg text-[#e8dcc8] mb-2">Page Not Found</p>
        <p className="text-sm text-[#8b9db8] mb-8">
          The page you are looking for does not exist or has been moved.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 bg-[#1a936f] text-[#0a1628] rounded-full px-6 py-2.5 text-sm font-medium hover:bg-[#22b382] transition-all duration-300"
        >
          <Home className="w-4 h-4" />
          Back to Home
        </Link>
      </div>
    </div>
  );
}
