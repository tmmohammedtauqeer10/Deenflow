import { Link } from "react-router";
import Hero from "@/sections/Hero";
import Footer from "@/sections/Footer";
import {
  BookOpen, Brain, MessageSquare, Mail, Clock, ScrollText,
  Sparkles, Calendar, BookMarked, ArrowRight, Star, Globe,
  BookOpenCheck,
} from "lucide-react";

const features = [
  { path: "/quran", title: "Holy Quran", desc: "Read & listen to all 114 Surahs with Kanzul Iman Urdu translation", icon: <BookOpen className="w-6 h-6" />, color: "#1a936f" },
  { path: "/prayer", title: "Prayer Times", desc: "Accurate Salah times with geolocation & Qibla direction", icon: <Clock className="w-6 h-6" />, color: "#1a936f" },
  { path: "/hadith", title: "Hadith Collections", desc: "22,000+ authentic hadiths from 5 major collections", icon: <ScrollText className="w-6 h-6" />, color: "#c9a66b" },
  { path: "/names", title: "99 Names of Allah", desc: "Learn Asma ul Husna with Arabic, transliteration & meaning", icon: <Sparkles className="w-6 h-6" />, color: "#c9a66b" },
  { path: "/calendar", title: "Hijri Calendar", desc: "Gregorian to Hijri date converter and calendar reference", icon: <Calendar className="w-6 h-6" />, color: "#1a936f" },
  { path: "/library", title: "Digital Library", desc: "Browse 15+ authentic Islamic books from your GitHub API", icon: <BookMarked className="w-6 h-6" />, color: "#1a936f" },
  { path: "/quiz", title: "Islamic Quiz", desc: "50 MCQs across Seerah, Quran, Hadith, Fiqh & History", icon: <Brain className="w-6 h-6" />, color: "#c9a66b" },
  { path: "/chat", title: "Ask AI", desc: "AI-powered Islamic knowledge assistant for any topic", icon: <MessageSquare className="w-6 h-6" />, color: "#1a936f" },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-[#0a1628]">
      <Hero scrollToSection={() => {}} />

      {/* Features Grid */}
      <section className="w-full bg-[#0a1628] py-24 md:py-32">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <div className="text-center mb-14">
            <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#1a936f]">
              FEATURES
            </span>
            <h2 className="font-display text-4xl md:text-5xl text-[#e8dcc8] mt-3">
              Everything Islamic, In One Place
            </h2>
            <p className="text-base text-[#8b9db8] mt-4 font-light max-w-[600px] mx-auto">
              Powered by 8 real, free Islamic APIs — from Quran and Hadith to Prayer Times and AI Chat.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {features.map((f) => (
              <Link
                key={f.path}
                to={f.path}
                className="group p-6 rounded-xl bg-[#0d1f3c] border border-[rgba(26,147,111,0.08)] hover:border-[rgba(26,147,111,0.25)] transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-all duration-300" style={{ backgroundColor: `${f.color}18`, color: f.color }}>
                  {f.icon}
                </div>
                <h3 className="text-base font-medium text-[#e8dcc8] group-hover:text-[#1a936f] transition-colors duration-300 flex items-center gap-2">
                  {f.title}
                  <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transform translate-x-0 group-hover:translate-x-1 transition-all duration-300" />
                </h3>
                <p className="text-sm text-[#8b9db8] mt-2 leading-relaxed">{f.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* API Resources Section */}
      <section className="w-full bg-[#0d1f3c] py-24 md:py-32">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
          <div className="text-center mb-14">
            <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-[#c9a66b]">
              API RESOURCES
            </span>
            <h2 className="font-display text-4xl md:text-5xl text-[#e8dcc8] mt-3">
              Real Islamic Data APIs
            </h2>
            <p className="text-base text-[#8b9db8] mt-4 font-light max-w-[600px] mx-auto">
              All content is sourced from verified, free Islamic APIs with local cache/SQLite-like storage for offline access.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { name: "Al-Quran Cloud", url: "api.alquran.cloud", desc: "Complete Quran with 30+ translations including Kanzul Iman (ur.ahmedali)", tags: ["Quran", "Audio", "Search"] },
              { name: "AlAdhan API", url: "api.aladhan.com", desc: "Prayer times, Hijri calendar, 99 Names of Allah, Qibla direction", tags: ["Prayer", "Hijri", "Qibla"] },
              { name: "Hadith API", url: "hadithapi.pages.dev", desc: "22,000+ hadiths from Bukhari, Muslim, Abu Dawud, Tirmidhi, Ibn Majah", tags: ["Hadith", "Search"] },
              { name: "DeenFlow CDN", url: "github.com/tmmohammedtauqeer10/Deenflow", desc: "Your GitHub repo serving book catalog & quiz data as JSON", tags: ["Library", "Quiz"] },
            ].map((api) => (
              <div key={api.name} className="p-5 rounded-xl bg-[#0a1628] border border-[rgba(26,147,111,0.08)]">
                <div className="flex items-center gap-2 mb-2">
                  <Globe className="w-4 h-4 text-[#1a936f]" />
                  <h3 className="text-sm font-medium text-[#e8dcc8]">{api.name}</h3>
                </div>
                <p className="text-xs text-[#5a6f85] mb-1">{api.url}</p>
                <p className="text-sm text-[#8b9db8] leading-relaxed">{api.desc}</p>
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {api.tags.map((tag) => (
                    <span key={tag} className="text-[10px] bg-[rgba(26,147,111,0.1)] text-[#1a936f] px-2 py-0.5 rounded-full">{tag}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Local Cache Info */}
          <div className="mt-8 p-5 rounded-xl bg-[rgba(26,147,111,0.05)] border border-[rgba(26,147,111,0.1)]">
            <div className="flex items-center gap-2 mb-2">
              <BookOpenCheck className="w-4 h-4 text-[#1a936f]" />
              <h3 className="text-sm font-medium text-[#1a936f]">Local Cache & JSON Fallback</h3>
            </div>
            <p className="text-sm text-[#8b9db8] leading-relaxed">
              All API responses are cached locally in your browser (localStorage) with a 7-day TTL. If an API is offline, DeenFlow will serve the cached data automatically. This ensures you always have access to Quranic verses, Hadith, Prayer Times, and 99 Names — even without an internet connection.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full bg-[#0a1628] py-20">
        <div className="max-w-[600px] mx-auto px-4 sm:px-6 text-center">
          <Star className="w-8 h-8 text-[#c9a66b] mx-auto mb-4" />
          <h2 className="font-display text-3xl text-[#e8dcc8]">Start Your Journey</h2>
          <p className="text-sm text-[#8b9db8] mt-3 mb-6">Explore the Quran, test your knowledge, or ask our AI anything about Islam.</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/quran" className="bg-[#1a936f] text-[#0a1628] rounded-full px-7 py-3 text-sm font-medium hover:bg-[#22b382] transition-all">Explore Quran</Link>
            <Link to="/chat" className="bg-transparent border border-[rgba(26,147,111,0.4)] text-[#1a936f] rounded-full px-7 py-3 text-sm font-medium hover:border-[#1a936f] transition-all">Ask AI</Link>
            <Link to="/contact" className="flex items-center justify-center gap-2 text-[#8b9db8] text-sm hover:text-[#1a936f] transition-colors"><Mail className="w-4 h-4" />Contact</Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
