import { useState, useEffect } from "react";
import { Scroll, Search, Loader2, BookOpen, ChevronRight, Shuffle } from "lucide-react";
import PageLayout from "@/components/PageLayout";
import { getHadith, getRandomHadith, searchHadith, HADITH_COLLECTIONS, type Hadith } from "@/lib/islamic-apis";

export default function HadithPage() {
  const [selectedCollection, setSelectedCollection] = useState<string | null>(null);
  const [hadithId, setHadithId] = useState(1);
  const [hadith, setHadith] = useState<Hadith | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Hadith[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [dailyHadith, setDailyHadith] = useState<Hadith | null>(null);

  useEffect(() => { getRandomHadith().then(setDailyHadith).catch(() => {}); }, []);

  useEffect(() => { if (selectedCollection) loadHadith(selectedCollection, hadithId); }, [selectedCollection, hadithId]);

  const loadHadith = async (collection: string, id: number) => {
    setLoading(true);
    try { setHadith(await getHadith(collection, id)); } catch { setHadith(null); }
    setLoading(false);
  };

  const handleRandom = async () => {
    setLoading(true);
    try { const d = await getRandomHadith(); setHadith(d); setSelectedCollection(null); } catch {}
    setLoading(false);
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    try { setSearchResults(await searchHadith(searchQuery)); } catch { setSearchResults([]); }
    setIsSearching(false);
  };

  return (
    <PageLayout title="Hadith Collections" subtitle="Browse over 22,000 authentic hadiths from Sahih Bukhari, Sahih Muslim, Sunan Abu Dawud, Jami at-Tirmidhi, and Sunan Ibn Majah." label="Hadith Explorer">
      {/* Daily Hadith */}
      {dailyHadith && !selectedCollection && (
        <div className="mb-10 p-6 rounded-xl bg-[rgba(201,166,107,0.06)] border border-[rgba(201,166,107,0.12)]">
          <div className="flex items-center gap-2 mb-3"><Shuffle className="w-4 h-4 text-[#c9a66b]" /><span className="text-xs text-[#c9a66b] uppercase tracking-wider font-medium">Random Hadith</span></div>
          <p className="text-sm text-[#e8dcc8] leading-relaxed italic">&ldquo;{dailyHadith.hadith_english}&rdquo;</p>
          <p className="text-xs text-[#8b9db8] mt-3">— {dailyHadith.narrator} &middot; {dailyHadith.bookName}</p>
        </div>
      )}

      {/* Search */}
      <div className="flex gap-3 mb-8">
        <div className="flex-1 relative"><Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5a6f85]" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleSearch()} placeholder="Search hadiths in English..." className="w-full bg-[#0d1f3c] border border-[rgba(139,157,184,0.15)] rounded-xl pl-11 pr-4 py-3 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)]" />
        </div>
        <button onClick={handleSearch} disabled={isSearching} className="bg-[#1a936f] text-[#0a1628] rounded-xl px-5 py-3 text-sm font-medium hover:bg-[#22b382] disabled:opacity-60 transition-all duration-300 flex items-center gap-2">
          {isSearching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />} Search
        </button>
        <button onClick={handleRandom} disabled={loading} className="bg-[#0d1f3c] border border-[rgba(201,166,107,0.2)] text-[#c9a66b] rounded-xl px-4 py-3 text-sm hover:border-[rgba(201,166,107,0.4)] transition-all duration-300 flex items-center gap-2"><Shuffle className="w-4 h-4" /> Random</button>
      </div>

      {!selectedCollection && !hadith && searchResults.length === 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {HADITH_COLLECTIONS.map((col) => (
            <button key={col.key} onClick={() => { setSelectedCollection(col.key); setHadithId(1); }} className="p-5 rounded-xl bg-[#0d1f3c] border border-[rgba(26,147,111,0.08)] hover:border-[rgba(26,147,111,0.25)] text-left transition-all duration-300 group">
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-lg bg-[rgba(26,147,111,0.1)] flex items-center justify-center"><BookOpen className="w-5 h-5 text-[#1a936f]" /></div>
                <ChevronRight className="w-4 h-4 text-[#5a6f85] group-hover:text-[#1a936f] transition-colors duration-300" />
              </div>
              <h3 className="text-sm font-medium text-[#e8dcc8] mt-3">{col.name}</h3>
              <p className="text-xs text-[#5a6f85] mt-1">{col.count.toLocaleString()} hadiths</p>
            </button>
          ))}
        </div>
      ) : null}

      {searchResults.length > 0 && !selectedCollection && (
        <div className="mb-8">
          <h3 className="text-sm font-medium text-[#e8dcc8] mb-4">Search Results ({searchResults.length})</h3>
          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            {searchResults.slice(0, 20).map((h, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-[#0d1f3c] border border-[rgba(26,147,111,0.06)]">
                <p className="text-xs text-[#1a936f] mb-2">{h.bookName} &middot; Hadith #{h.hadithNumber}</p>
                <p className="text-sm text-[#e8dcc8] leading-relaxed">{h.hadith_english.length > 300 ? h.hadith_english.substring(0, 300) + "..." : h.hadith_english}</p>
                <p className="text-xs text-[#8b9db8] mt-2">— {h.narrator}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {(selectedCollection || hadith) && (
        <div>
          {selectedCollection && (
            <div className="flex items-center justify-between mb-6">
              <button onClick={() => { setSelectedCollection(null); setHadith(null); }} className="text-xs text-[#1a936f] hover:underline">&larr; Back to Collections</button>
              <div className="flex items-center gap-2">
                <button onClick={() => setHadithId(Math.max(1, hadithId - 1))} className="px-3 py-1.5 rounded-lg bg-[#0d1f3c] border border-[rgba(139,157,184,0.15)] text-xs text-[#e8dcc8] hover:border-[rgba(26,147,111,0.3)] transition-all duration-200">Previous</button>
                <span className="text-xs text-[#8b9db8] min-w-[80px] text-center]">Hadith #{hadithId}</span>
                <button onClick={() => setHadithId(hadithId + 1)} className="px-3 py-1.5 rounded-lg bg-[#0d1f3c] border border-[rgba(139,157,184,0.15)] text-xs text-[#e8dcc8] hover:border-[rgba(26,147,111,0.3)] transition-all duration-200">Next</button>
              </div>
            </div>
          )}
          {loading ? <div className="flex items-center justify-center py-16"><Loader2 className="w-8 h-8 text-[#1a936f] animate-spin" /></div>
          : hadith ? (
            <div className="p-6 md:p-8 rounded-xl bg-[#0d1f3c] border border-[rgba(26,147,111,0.1)]">
              <div className="flex items-center gap-2 mb-4">
                <Scroll className="w-4 h-4 text-[#c9a66b]" />
                <span className="text-xs text-[#c9a66b] uppercase tracking-wider font-medium">{hadith.bookName} &middot; #{hadith.hadithNumber}</span>
                {hadith.grade && <span className="ml-auto text-[10px] bg-[rgba(26,147,111,0.12)] text-[#1a936f] px-2 py-0.5 rounded-full">{hadith.grade}</span>}
              </div>
              {hadith.chapter && <p className="text-xs text-[#8b9db8] mb-4">Chapter: {hadith.chapter}</p>}
              <p className="text-[15px] text-[#e8dcc8] leading-[1.9]">&ldquo;{hadith.hadith_english}&rdquo;</p>
              <div className="mt-6 pt-4 border-t border-[rgba(26,147,111,0.08)]"><p className="text-sm text-[#8b9db8]">Narrated by: <span className="text-[#c9a66b]">{hadith.narrator}</span></p></div>
            </div>
          ) : <div className="text-center py-16 text-[#8b9db8]"><Scroll className="w-12 h-12 mx-auto mb-4 opacity-30" /><p>Hadith not found.</p></div>}
        </div>
      )}
    </PageLayout>
  );
}
