import { useEffect } from "react";
import { Link, useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import {
  ArrowLeft,
  Users,
  BookOpen,
  Brain,
  Mail,
  MessageSquare,
  Trash2,
  Loader2,
  Shield,
  Trophy,
} from "lucide-react";

export default function AdminDashboard() {
  const { user, isAdmin, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !user) {
      navigate("/login");
    }
    if (!isLoading && user && !isAdmin) {
      navigate("/");
    }
  }, [isLoading, user, isAdmin, navigate]);

  const { data: stats, isLoading: statsLoading } = trpc.admin.stats.useQuery(undefined, {
    enabled: isAdmin,
  });

  const { data: contacts, isLoading: contactsLoading } = trpc.contact.list.useQuery(undefined, {
    enabled: isAdmin,
  });

  const { data: usersData } = trpc.admin.users.useQuery(undefined, {
    enabled: isAdmin,
  });

  const { data: quizData } = trpc.admin.quizResults.useQuery(undefined, {
    enabled: isAdmin,
  });

  const utils = trpc.useUtils();
  const deleteContact = trpc.contact.delete.useMutation({
    onSuccess: () => {
      utils.contact.list.invalidate();
      utils.admin.stats.invalidate();
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0a1628] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#1a936f] animate-spin" />
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-[#0a1628]">
      {/* Header */}
      <div className="border-b border-[rgba(26,147,111,0.1)]">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link
              to="/"
              className="text-[#8b9db8] hover:text-[#1a936f] transition-colors duration-300"
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-[#c9a66b]" />
              <h1 className="font-display text-xl text-[#e8dcc8]">Admin Dashboard</h1>
            </div>
          </div>
          <span className="text-xs text-[#8b9db8]">{user?.name}</span>
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-8">
        {/* Stats Grid */}
        {statsLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 text-[#1a936f] animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-10">
            <StatCard icon={<Users className="w-5 h-5" />} label="OAuth Users" value={stats?.totalUsers || 0} />
            <StatCard icon={<Users className="w-5 h-5" />} label="Local Users" value={stats?.totalLocalUsers || 0} />
            <StatCard icon={<BookOpen className="w-5 h-5" />} label="Bookmarks" value={stats?.totalBookmarks || 0} />
            <StatCard icon={<Brain className="w-5 h-5" />} label="Quiz Attempts" value={stats?.totalQuizAttempts || 0} />
            <StatCard icon={<Mail className="w-5 h-5" />} label="Contacts" value={stats?.totalContacts || 0} />
            <StatCard icon={<MessageSquare className="w-5 h-5" />} label="Chat Messages" value={stats?.totalChats || 0} />
          </div>
        )}

        {/* Contact Submissions */}
        <div className="mb-10">
          <h2 className="font-display text-xl text-[#e8dcc8] mb-4 flex items-center gap-2">
            <Mail className="w-5 h-5 text-[#1a936f]" />
            Contact Submissions
          </h2>
          <div className="bg-[#0d1f3c] rounded-xl border border-[rgba(26,147,111,0.1)] overflow-hidden">
            {contactsLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-5 h-5 text-[#1a936f] animate-spin" />
              </div>
            ) : contacts && contacts.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[rgba(26,147,111,0.1)]">
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Name</th>
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Email</th>
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Message</th>
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Date</th>
                      <th className="text-right text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {contacts.map((contact) => (
                      <tr
                        key={contact.id}
                        className="border-b border-[rgba(26,147,111,0.05)] hover:bg-[rgba(26,147,111,0.03)] transition-colors duration-200"
                      >
                        <td className="px-4 py-3 text-sm text-[#e8dcc8]">{contact.name}</td>
                        <td className="px-4 py-3 text-sm text-[#8b9db8]">{contact.email}</td>
                        <td className="px-4 py-3 text-sm text-[#8b9db8] max-w-[300px] truncate">{contact.message}</td>
                        <td className="px-4 py-3 text-xs text-[#5a6f85]">
                          {contact.createdAt ? new Date(contact.createdAt).toLocaleDateString() : "N/A"}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            onClick={() => deleteContact.mutate({ id: contact.id })}
                            className="text-[#c53030] hover:text-[#e53e3e] transition-colors duration-300"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8 text-sm text-[#5a6f85]">No contact submissions yet.</div>
            )}
          </div>
        </div>

        {/* Users */}
        <div className="mb-10">
          <h2 className="font-display text-xl text-[#e8dcc8] mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-[#1a936f]" />
            Users
          </h2>
          <div className="bg-[#0d1f3c] rounded-xl border border-[rgba(26,147,111,0.1)] overflow-hidden">
            {usersData ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[rgba(26,147,111,0.1)]">
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">ID</th>
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Name</th>
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Email</th>
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Type</th>
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Role</th>
                    </tr>
                  </thead>
                  <tbody>
                    {usersData.oauthUsers.map((u) => (
                      <tr key={`oauth-${u.id}`} className="border-b border-[rgba(26,147,111,0.05)]">
                        <td className="px-4 py-3 text-xs text-[#5a6f85]">{u.id}</td>
                        <td className="px-4 py-3 text-sm text-[#e8dcc8]">{u.name || "N/A"}</td>
                        <td className="px-4 py-3 text-sm text-[#8b9db8]">{u.email || "N/A"}</td>
                        <td className="px-4 py-3 text-xs">
                          <span className="bg-[rgba(26,147,111,0.15)] text-[#1a936f] px-2 py-0.5 rounded-full">OAuth</span>
                        </td>
                        <td className="px-4 py-3 text-xs text-[#8b9db8]">{u.role}</td>
                      </tr>
                    ))}
                    {usersData.localUsers.map((u) => (
                      <tr key={`local-${u.id}`} className="border-b border-[rgba(26,147,111,0.05)]">
                        <td className="px-4 py-3 text-xs text-[#5a6f85]">{u.id}</td>
                        <td className="px-4 py-3 text-sm text-[#e8dcc8]">{u.displayName || u.username}</td>
                        <td className="px-4 py-3 text-sm text-[#8b9db8]">{u.email}</td>
                        <td className="px-4 py-3 text-xs">
                          <span className="bg-[rgba(201,166,107,0.15)] text-[#c9a66b] px-2 py-0.5 rounded-full">Local</span>
                        </td>
                        <td className="px-4 py-3 text-xs text-[#8b9db8]">{u.role}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8 text-sm text-[#5a6f85]">Loading users...</div>
            )}
          </div>
        </div>

        {/* Quiz Results */}
        <div>
          <h2 className="font-display text-xl text-[#e8dcc8] mb-4 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-[#c9a66b]" />
            Quiz Results
          </h2>
          <div className="bg-[#0d1f3c] rounded-xl border border-[rgba(26,147,111,0.1)] overflow-hidden">
            {quizData && quizData.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[rgba(26,147,111,0.1)]">
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">User</th>
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Category</th>
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Score</th>
                      <th className="text-left text-xs text-[#8b9db8] font-medium uppercase tracking-wider px-4 py-3">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {quizData.map((q) => (
                      <tr key={q.id} className="border-b border-[rgba(26,147,111,0.05)]">
                        <td className="px-4 py-3 text-sm text-[#e8dcc8]">
                          {q.userId || q.localUserId || "Anonymous"}
                        </td>
                        <td className="px-4 py-3 text-sm text-[#8b9db8]">{q.category}</td>
                        <td className="px-4 py-3 text-sm">
                          <span className="text-[#c9a66b] font-medium">
                            {q.score}/{q.totalQuestions}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-xs text-[#5a6f85]">
                          {q.createdAt ? new Date(q.createdAt).toLocaleDateString() : "N/A"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8 text-sm text-[#5a6f85]">No quiz results yet.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
}) {
  return (
    <div className="bg-[#0d1f3c] rounded-xl border border-[rgba(26,147,111,0.1)] p-4">
      <div className="flex items-center gap-2 mb-2">
        <span className="text-[#1a936f]">{icon}</span>
        <span className="text-xs text-[#8b9db8]">{label}</span>
      </div>
      <p className="text-2xl font-display text-[#e8dcc8]">{value}</p>
    </div>
  );
}
