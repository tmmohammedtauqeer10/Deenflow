import { useState } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { Star, LogIn, UserPlus, ArrowLeft, Loader2, Sparkles } from "lucide-react";

function getOAuthUrl() {
  const appId = import.meta.env.VITE_APP_ID;
  const authUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${authUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appId);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState("");

  const loginMutation = trpc.localAuth.login.useMutation({
    onSuccess: (data) => {
      localStorage.setItem("local_auth_token", data.token);
      window.location.href = "/";
    },
    onError: (err) => {
      setError(err.message);
    },
  });

  const registerMutation = trpc.localAuth.register.useMutation({
    onSuccess: (data) => {
      localStorage.setItem("local_auth_token", data.token);
      window.location.href = "/";
    },
    onError: (err) => {
      setError(err.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (mode === "login") {
      loginMutation.mutate({ username, password });
    } else {
      if (password.length < 6) {
        setError("Password must be at least 6 characters");
        return;
      }
      registerMutation.mutate({
        username,
        email,
        password,
        displayName: displayName || undefined,
      });
    }
  };

  const isPending = loginMutation.isPending || registerMutation.isPending;

  return (
    <div className="min-h-screen bg-[#0a1628] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Back link */}
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm text-[#8b9db8] hover:text-[#1a936f] transition-colors duration-300 mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        {/* Logo */}
        <div className="flex items-center gap-2 mb-8">
          <Star className="w-6 h-6 text-[#1a936f]" />
          <span className="font-display text-2xl text-[#e8dcc8]">DeenFlow</span>
        </div>

        <h1 className="font-display text-3xl text-[#e8dcc8] mb-2">
          {mode === "login" ? "Welcome Back" : "Get Started"}
        </h1>
        <p className="text-sm text-[#8b9db8] mb-8">
          {mode === "login"
            ? "Sign in to access your bookmarks and quiz history."
            : "Create an account to start your Islamic knowledge journey."}
        </p>

        {/* OAuth Button */}
        <a
          href={getOAuthUrl()}
          className="w-full flex items-center justify-center gap-2 bg-[#0d1f3c] border border-[rgba(26,147,111,0.2)] text-[#e8dcc8] rounded-xl py-3 text-sm font-medium hover:border-[rgba(26,147,111,0.4)] transition-all duration-300 mb-6"
        >
          <Sparkles className="w-4 h-4 text-[#1a936f]" />
          Continue with OAuth
        </a>

        {/* Divider */}
        <div className="flex items-center gap-3 mb-6">
          <div className="flex-1 h-px bg-[rgba(139,157,184,0.15)]" />
          <span className="text-xs text-[#5a6f85] uppercase tracking-wider">or</span>
          <div className="flex-1 h-px bg-[rgba(139,157,184,0.15)]" />
        </div>

        {/* Local Auth Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="text-xs text-[#8b9db8] mb-1.5 block">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              className="w-full bg-[#0d1f3c] border border-[rgba(139,157,184,0.15)] rounded-xl px-4 py-3 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)] transition-colors duration-300"
              placeholder="Enter username"
            />
          </div>

          {mode === "register" && (
            <>
              <div>
                <label className="text-xs text-[#8b9db8] mb-1.5 block">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full bg-[#0d1f3c] border border-[rgba(139,157,184,0.15)] rounded-xl px-4 py-3 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)] transition-colors duration-300"
                  placeholder="Enter email"
                />
              </div>
              <div>
                <label className="text-xs text-[#8b9db8] mb-1.5 block">Display Name (optional)</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full bg-[#0d1f3c] border border-[rgba(139,157,184,0.15)] rounded-xl px-4 py-3 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)] transition-colors duration-300"
                  placeholder="How should we call you?"
                />
              </div>
            </>
          )}

          <div>
            <label className="text-xs text-[#8b9db8] mb-1.5 block">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full bg-[#0d1f3c] border border-[rgba(139,157,184,0.15)] rounded-xl px-4 py-3 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)] transition-colors duration-300"
              placeholder={mode === "register" ? "Min 6 characters" : "Enter password"}
            />
          </div>

          {error && (
            <p className="text-sm text-[#c53030]">{error}</p>
          )}

          <button
            type="submit"
            disabled={isPending}
            className="w-full bg-[#1a936f] text-[#0a1628] rounded-xl py-3 text-sm font-medium hover:bg-[#22b382] disabled:opacity-60 transition-all duration-300 flex items-center justify-center gap-2"
          >
            {isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : mode === "login" ? (
              <>
                <LogIn className="w-4 h-4" />
                Sign In
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                Create Account
              </>
            )}
          </button>
        </form>

        {/* Toggle mode */}
        <p className="text-center text-sm text-[#8b9db8] mt-6">
          {mode === "login" ? (
            <>
              Don't have an account?{" "}
              <button
                onClick={() => {
                  setMode("register");
                  setError("");
                }}
                className="text-[#1a936f] hover:underline"
              >
                Get Started
              </button>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <button
                onClick={() => {
                  setMode("login");
                  setError("");
                }}
                className="text-[#1a936f] hover:underline"
              >
                Sign In
              </button>
            </>
          )}
        </p>
      </div>
    </div>
  );
}
