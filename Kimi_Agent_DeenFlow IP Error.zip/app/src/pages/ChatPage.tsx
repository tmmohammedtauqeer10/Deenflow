import { useState, useRef, useEffect } from "react";
import { Send, User, Diamond, Loader2, BookOpen, Database, Sparkles } from "lucide-react";
import { trpc } from "@/providers/trpc";
import PageLayout from "@/components/PageLayout";
import { TOTAL_KNOWLEDGE_ENTRIES, KNOWLEDGE_CATEGORIES } from "@/data/islamic-knowledge";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export default function ChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content:
        "As-salamu alaykum! I am your Islamic knowledge assistant, trained on **60+ authentic knowledge entries** from the Quran, Sahih Hadith (Bukhari, Muslim), Fiqh, Aqeedah, Seerah, Ethics, and Dua. Ask me anything about Islam!",
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: knowledgeStats } = trpc.chat.knowledgeStats.useQuery();

  const sendMessage = trpc.chat.send.useMutation({
    onSuccess: (data) => {
      setMessages((prev) => [...prev, { role: "assistant", content: data.response }]);
      setIsTyping(false);
    },
    onError: () => {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "I apologize, but I'm having trouble. Please try again.",
        },
      ]);
      setIsTyping(false);
    },
  });

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!input.trim() || isTyping) return;
    const userMessage = input.trim();
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setInput("");
    setIsTyping(true);
    sendMessage.mutate({ message: userMessage });
  };

  return (
    <PageLayout
      title="Your Islamic Knowledge Assistant"
      subtitle="Trained on 60+ authentic knowledge entries from Quran, Sahih Hadith, Fiqh, Aqeedah, Seerah, Ethics, and Dua."
      label="Ask AI"
    >
      {/* Knowledge Stats Bar */}
      <div className="flex flex-wrap items-center gap-4 mb-6 p-4 rounded-xl bg-[rgba(26,147,111,0.06)] border border-[rgba(26,147,111,0.1)]">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-[#1a936f]" />
          <span className="text-xs text-[#1a936f] font-medium">
            {knowledgeStats?.totalEntries || TOTAL_KNOWLEDGE_ENTRIES} Knowledge Entries
          </span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {(knowledgeStats?.categories || KNOWLEDGE_CATEGORIES.map((c) => ({ category: c.key, name: c.name, count: c.count }))).map((cat) => (
            <span
              key={cat.category}
              className="text-[10px] bg-[rgba(26,147,111,0.1)] text-[#1a936f] px-2 py-0.5 rounded-full"
            >
              {cat.name}: {cat.count}
            </span>
          ))}
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <BookOpen className="w-3.5 h-3.5 text-[#c9a66b]" />
          <span className="text-[10px] text-[#8b9db8]">Sources: Quran, Bukhari, Muslim, Tirmidhi, Nasa&apos;i, Abu Dawud, Ibn Majah</span>
        </div>
      </div>

      {/* Chat Interface */}
      <div
        className="bg-[#0d1f3c] rounded-2xl border border-[rgba(26,147,111,0.15)] flex flex-col"
        style={{ height: "55vh", minHeight: "400px" }}
      >
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
            >
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                  msg.role === "assistant"
                    ? "bg-[rgba(26,147,111,0.15)]"
                    : "bg-[rgba(201,166,107,0.15)]"
                }`}
              >
                {msg.role === "assistant" ? (
                  <Diamond className="w-4 h-4 text-[#1a936f]" />
                ) : (
                  <User className="w-4 h-4 text-[#c9a66b]" />
                )}
              </div>
              <div
                className={`max-w-[80%] px-4 py-3 rounded-xl text-sm leading-relaxed whitespace-pre-wrap ${
                  msg.role === "assistant"
                    ? "bg-[rgba(26,147,111,0.08)] text-[#e8dcc8] rounded-tl-sm"
                    : "bg-[rgba(201,166,107,0.08)] text-[#e8dcc8] rounded-tr-sm"
                }`}
              >
                {msg.content}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3">
              <div className="w-9 h-9 rounded-full bg-[rgba(26,147,111,0.15)] flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4 text-[#1a936f]" />
              </div>
              <div className="bg-[rgba(26,147,111,0.08)] px-4 py-3 rounded-xl rounded-tl-sm">
                <div className="flex gap-1.5">
                  <span
                    className="w-2 h-2 rounded-full bg-[#1a936f] animate-pulse-dot"
                    style={{ animationDelay: "0ms" }}
                  />
                  <span
                    className="w-2 h-2 rounded-full bg-[#1a936f] animate-pulse-dot"
                    style={{ animationDelay: "200ms" }}
                  />
                  <span
                    className="w-2 h-2 rounded-full bg-[#1a936f] animate-pulse-dot"
                    style={{ animationDelay: "400ms" }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-[rgba(26,147,111,0.1)] px-4 md:px-6 py-4">
          <div className="flex items-center gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Ask about Quran, Hadith, Fiqh, Seerah, Dua..."
              className="flex-1 bg-[#0a1628] border border-[rgba(139,157,184,0.15)] rounded-full px-5 py-3 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)]"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="w-10 h-10 rounded-full bg-[#1a936f] flex items-center justify-center hover:bg-[#22b382] disabled:opacity-40 transition-all duration-300 shrink-0"
            >
              {isTyping ? (
                <Loader2 className="w-4 h-4 text-[#0a1628] animate-spin" />
              ) : (
                <Send className="w-4 h-4 text-[#0a1628]" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Sample Questions */}
      <div className="mt-6">
        <p className="text-xs text-[#8b9db8] mb-3 uppercase tracking-wider">Try asking about:</p>
        <div className="flex flex-wrap gap-2">
          {[
            "What is the Quran?",
            "Tell me about Surah Al-Fatiha",
            "How to perform Wudu?",
            "What are the Five Pillars?",
            "Tell me about Ramadan",
            "What is Tawhid?",
            "How to pray Istikhara?",
            "Daily Adhkar for protection",
            "What happens after death?",
            "Who were the Khulafa Rashidun?",
          ].map((q) => (
            <button
              key={q}
              onClick={() => {
                setInput(q);
              }}
              className="px-3 py-1.5 rounded-full text-[11px] bg-[#0d1f3c] border border-[rgba(139,157,184,0.12)] text-[#8b9db8] hover:border-[rgba(26,147,111,0.3)] hover:text-[#1a936f] transition-all duration-200"
            >
              {q}
            </button>
          ))}
        </div>
      </div>
    </PageLayout>
  );
}
