import { useState, useEffect } from "react";
import { Bookmark, BookmarkCheck, ExternalLink, Loader2 } from "lucide-react";
import PageLayout from "@/components/PageLayout";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import type { LibraryApi, LibraryBook } from "@/types/api";

const LIBRARY_API = "https://raw.githubusercontent.com/tmmohammedtauqeer10/Deenflow/main/library_api.json";
const coverImages = ["/book-cover-1.jpg", "/book-cover-2.jpg", "/book-cover-3.jpg", "/book-cover-4.jpg", "/book-cover-5.jpg", "/book-cover-6.jpg"];

export default function LibraryPage() {
  const [data, setData] = useState<LibraryApi | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState("All");
  const { isAuthenticated } = useAuth();
  const { data: bookmarks } = trpc.bookmark.list.useQuery(undefined, { enabled: isAuthenticated });
  const utils = trpc.useUtils();
  const addBookmark = trpc.bookmark.add.useMutation({ onSuccess: () => utils.bookmark.list.invalidate() });
  const removeBookmark = trpc.bookmark.remove.useMutation({ onSuccess: () => utils.bookmark.list.invalidate() });

  useEffect(() => {
    fetch(LIBRARY_API).then((r) => r.json()).then((d: LibraryApi) => { setData(d); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const bookmarkedIds = new Set(bookmarks?.map((b) => b.bookId) || []);
  const filters = ["All", "Quran", "Hadith", "Fiqh", "Seerah", "Aqeedah", "History"];

  const filteredCategories = data?.categories.filter((cat) => {
    if (activeFilter === "All") return true;
    if (activeFilter === "Quran") return cat.category_name.toLowerCase().includes("quran") || cat.category_name.toLowerCase().includes("tafsir") || cat.category_name.toLowerCase().includes("tajweed");
    if (activeFilter === "Hadith") return cat.category_name.toLowerCase().includes("hadith");
    if (activeFilter === "Fiqh") return cat.category_name.toLowerCase().includes("fiqh");
    if (activeFilter === "Seerah") return cat.category_name.toLowerCase().includes("seerah");
    if (activeFilter === "Aqeedah") return cat.category_name.toLowerCase().includes("aqeedah");
    if (activeFilter === "History") return cat.category_name.toLowerCase().includes("history");
    return true;
  }) || [];

  const toggleBookmark = (book: LibraryBook) => {
    if (!isAuthenticated) { window.location.href = "/login"; return; }
    if (bookmarkedIds.has(book.id)) { const bm = bookmarks?.find((b) => b.bookId === book.id); if (bm) removeBookmark.mutate({ id: bm.id }); }
    else addBookmark.mutate({ bookId: book.id, bookTitle: book.title, bookAuthor: book.author, bookCategory: book.badge, pdfUrl: book.pdf_url });
  };

  return (
    <PageLayout title="Digital Library" subtitle="Browse our collection of authentic Islamic books across Quranic studies, Hadith, Fiqh, Seerah, and more." label="Library">
      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-8">
        {filters.map((f) => (
          <button key={f} onClick={() => setActiveFilter(f)} className={`px-4 py-2 rounded-full text-xs font-medium transition-all duration-300 ${activeFilter === f ? "bg-[rgba(26,147,111,0.15)] text-[#1a936f]" : "border border-[rgba(139,157,184,0.2)] text-[#8b9db8] hover:border-[rgba(26,147,111,0.3)]"}`}>{f}</button>
        ))}
      </div>
      {loading && <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 text-[#1a936f] animate-spin" /></div>}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredCategories.map((cat, catIdx) => cat.books.map((book, bookIdx) => {
          const imgIdx = (catIdx * 3 + bookIdx) % coverImages.length;
          const isBookmarked = bookmarkedIds.has(book.id);
          return (
            <div key={book.id} className="group bg-[#0d1f3c] rounded-xl border border-[rgba(26,147,111,0.1)] overflow-hidden hover:border-[rgba(26,147,111,0.3)] hover:-translate-y-1 hover:shadow-[0_8px_32px_rgba(26,147,111,0.08)] transition-all duration-400">
              <div className="relative aspect-[3/4] overflow-hidden">
                <img src={coverImages[imgIdx]} alt={book.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-[rgba(10,22,40,0.9)] via-transparent to-transparent" />
                <button onClick={() => toggleBookmark(book)} className="absolute top-3 right-3 w-8 h-8 rounded-full bg-[rgba(10,22,40,0.6)] backdrop-blur-sm flex items-center justify-center hover:bg-[rgba(26,147,111,0.3)] transition-all duration-300">
                  {isBookmarked ? <BookmarkCheck className="w-4 h-4 text-[#1a936f]" /> : <Bookmark className="w-4 h-4 text-[#e8dcc8]" />}
                </button>
              </div>
              <div className="p-5">
                <span className="inline-block bg-[rgba(201,166,107,0.15)] text-[#c9a66b] text-[11px] font-medium px-3 py-1 rounded-full">{book.badge}</span>
                <h3 className="text-[15px] font-medium text-[#e8dcc8] mt-3 leading-snug">{book.title}</h3>
                <p className="text-[13px] text-[#8b9db8] mt-1">{book.author}</p>
                <p className="text-[12px] text-[#5a6f85] mt-2">{book.pages} pages &middot; {book.language}</p>
                <a href={book.pdf_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-[13px] font-medium text-[#1a936f] mt-4 hover:underline">Read Book <ExternalLink className="w-3 h-3" /></a>
              </div>
            </div>
          );
        }))}
      </div>
    </PageLayout>
  );
}
