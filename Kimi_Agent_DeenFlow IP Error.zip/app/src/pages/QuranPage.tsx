import { useState, useEffect, useRef } from "react";
import { Search, ChevronLeft, Pause, Loader2, Languages, Volume2, X } from "lucide-react";
import PageLayout from "@/components/PageLayout";
import {
  getAllSurahs, getSurah, searchQuran,
  TRANSLATION_EDITIONS,
  type Surah, type Ayah,
} from "@/lib/islamic-apis";

export default function QuranPage() {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [selectedSurah, setSelectedSurah] = useState<number | null>(null);
  const [ayahs, setAyahs] = useState<Ayah[]>([]);
  const [surahInfo, setSurahInfo] = useState<Surah | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingAyahs, setLoadingAyahs] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [translationEd, setTranslationEd] = useState("en.sahih");
  const [translationAyahs, setTranslationAyahs] = useState<Ayah[]>([]);
  const [playingAudio, setPlayingAudio] = useState<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    getAllSurahs()
      .then((data) => { setSurahs(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (selectedSurah) {
      setLoadingAyahs(true);
      Promise.all([getSurah(selectedSurah), getSurah(selectedSurah, translationEd)])
        .then(([arabicData, transData]) => {
          setAyahs(arabicData.ayahs);
          setTranslationAyahs(transData.ayahs);
          setSurahInfo(arabicData.surah);
          setLoadingAyahs(false);
        })
        .catch(() => setLoadingAyahs(false));
    }
  }, [selectedSurah, translationEd]);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    try { setSearchResults(await searchQuran(searchQuery)); } catch { setSearchResults([]); }
    setIsSearching(false);
  };

  const playAyahAudio = (ayahNumber: number, audioUrl: string) => {
    if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
    if (playingAudio === ayahNumber) { setPlayingAudio(null); return; }
    const audio = new Audio(audioUrl);
    audio.play(); audio.onended = () => setPlayingAudio(null);
    audioRef.current = audio; setPlayingAudio(ayahNumber);
  };

  return (
    <PageLayout title="The Holy Quran" subtitle="Read, listen, and search the complete Quran with translations including Kanzul Iman by Imam Ahmad Raza Khan, Sahih International, Pickthall, and more." label="Quran Explorer">
      {/* Search bar */}
      <div className="flex gap-3 mb-8">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5a6f85]" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleSearch()} placeholder="Search Quran in English..." className="w-full bg-[#0d1f3c] border border-[rgba(139,157,184,0.15)] rounded-xl pl-11 pr-4 py-3 text-sm text-[#e8dcc8] placeholder:text-[#5a6f85] focus:outline-none focus:border-[rgba(26,147,111,0.4)]" />
        </div>
        <button onClick={handleSearch} disabled={isSearching} className="bg-[#1a936f] text-[#0a1628] rounded-xl px-5 py-3 text-sm font-medium hover:bg-[#22b382] disabled:opacity-60 transition-all duration-300 flex items-center gap-2">
          {isSearching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />} Search
        </button>
        {searchResults.length > 0 && (
          <button onClick={() => { setSearchResults([]); setSearchQuery(""); }} className="bg-[#0d1f3c] border border-[rgba(139,157,184,0.15)] text-[#8b9db8] rounded-xl px-4 py-3 hover:border-[rgba(26,147,111,0.3)] transition-all duration-300"><X className="w-4 h-4" /></button>
        )}
      </div>

      {/* Translation selector */}
      {selectedSurah && (
        <div className="flex items-center gap-3 mb-6">
          <Languages className="w-4 h-4 text-[#1a936f]" />
          <select value={translationEd} onChange={(e) => setTranslationEd(e.target.value)} className="bg-[#0d1f3c] border border-[rgba(139,157,184,0.15)] rounded-lg px-3 py-2 text-sm text-[#e8dcc8] focus:outline-none focus:border-[rgba(26,147,111,0.4)]">
            {TRANSLATION_EDITIONS.map((ed) => (<option key={ed.identifier} value={ed.identifier}>{ed.name}</option>))}
          </select>
          <button onClick={() => { setSelectedSurah(null); setAyahs([]); setSurahInfo(null); }} className="ml-auto flex items-center gap-1.5 text-xs text-[#1a936f] hover:underline"><ChevronLeft className="w-3 h-3" /> Back to Surahs</button>
        </div>
      )}

      {/* Search Results */}
      {searchResults.length > 0 && (
        <div className="bg-[#0d1f3c] rounded-xl border border-[rgba(26,147,111,0.1)] p-5 mb-8">
          <h3 className="text-sm font-medium text-[#e8dcc8] mb-4">Search Results ({searchResults.length})</h3>
          <div className="space-y-3 max-h-[400px] overflow-y-auto">
            {searchResults.slice(0, 20).map((match, idx) => (
              <button key={idx} onClick={() => { setSelectedSurah(match.surah.number); setSearchResults([]); }} className="w-full text-left p-3 rounded-lg bg-[#0a1628] border border-[rgba(139,157,184,0.08)] hover:border-[rgba(26,147,111,0.2)] transition-all duration-200">
                <span className="text-xs text-[#1a936f]">Surah {match.surah.englishName} ({match.surah.number}:{match.numberInSurah})</span>
                <p className="text-sm text-[#e8dcc8] mt-1 truncate">{match.text}</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Surah List or Ayah View */}
      {!selectedSurah ? (
        loading ? (
          <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 text-[#1a936f] animate-spin" /></div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {surahs.map((surah) => (
              <button key={surah.number} onClick={() => setSelectedSurah(surah.number)} className="flex items-center gap-4 p-4 rounded-xl bg-[#0d1f3c] border border-[rgba(26,147,111,0.08)] hover:border-[rgba(26,147,111,0.25)] hover:bg-[rgba(26,147,111,0.04)] transition-all duration-300 text-left">
                <div className="w-10 h-10 rounded-lg bg-[rgba(26,147,111,0.12)] flex items-center justify-center shrink-0"><span className="text-sm font-medium text-[#1a936f]">{surah.number}</span></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#e8dcc8]">{surah.englishName}</p>
                  <p className="text-xs text-[#8b9db8] mt-0.5">{surah.englishNameTranslation}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-display text-[#c9a66b]">{surah.name}</p>
                  <p className="text-[11px] text-[#5a6f85]">{surah.numberOfAyahs} verses</p>
                </div>
              </button>
            ))}
          </div>
        )
      ) : (
        <div>
          {surahInfo && (
            <div className="text-center mb-8 p-6 bg-[#0d1f3c] rounded-xl border border-[rgba(26,147,111,0.1)]">
              <h3 className="font-display text-2xl text-[#e8dcc8]">{surahInfo.englishName}</h3>
              <p className="text-lg font-display text-[#c9a66b] mt-1">{surahInfo.name}</p>
              <p className="text-sm text-[#8b9db8] mt-2">{surahInfo.englishNameTranslation} &middot; {surahInfo.revelationType} &middot; {surahInfo.numberOfAyahs} Verses</p>
            </div>
          )}
          {loadingAyahs ? (
            <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 text-[#1a936f] animate-spin" /></div>
          ) : (
            <div className="space-y-4">
              {ayahs.map((ayah, idx) => (
                <div key={ayah.number} id={`ayah-${ayah.numberInSurah}`} className="p-5 rounded-xl bg-[#0d1f3c] border border-[rgba(26,147,111,0.06)] hover:border-[rgba(26,147,111,0.15)] transition-all duration-200">
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-full bg-[rgba(26,147,111,0.1)] flex items-center justify-center shrink-0 mt-1"><span className="text-xs font-medium text-[#1a936f]">{ayah.numberInSurah}</span></div>
                    <div className="flex-1">
                      <p className="text-xl leading-[2.2] text-[#e8dcc8] font-semibold text-right" dir="rtl">{ayah.text}</p>
                      {translationAyahs[idx] && (<p className="text-sm text-[#8b9db8] mt-3 leading-relaxed">{translationAyahs[idx].text}</p>)}
                    </div>
                  </div>
                  {ayah.audio && (
                    <div className="mt-3 flex justify-end">
                      <button onClick={() => playAyahAudio(ayah.number, ayah.audio)} className="flex items-center gap-1.5 text-xs text-[#1a936f] hover:text-[#22b382] transition-colors duration-300">
                        {playingAudio === ayah.number ? (<><Pause className="w-3.5 h-3.5" /> Stop</>) : (<><Volume2 className="w-3.5 h-3.5" /> Listen</>)}
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </PageLayout>
  );
}
