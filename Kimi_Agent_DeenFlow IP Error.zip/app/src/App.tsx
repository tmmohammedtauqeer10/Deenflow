import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import QuranPage from './pages/QuranPage'
import PrayerPage from './pages/PrayerPage'
import HadithPage from './pages/HadithPage'
import NamesPage from './pages/NamesPage'
import CalendarPage from './pages/CalendarPage'
import LibraryPage from './pages/LibraryPage'
import QuizPage from './pages/QuizPage'
import ChatPage from './pages/ChatPage'
import ContactPage from './pages/ContactPage'
import Login from './pages/Login'
import AdminDashboard from './pages/AdminDashboard'
import NotFound from './pages/NotFound'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/quran" element={<QuranPage />} />
      <Route path="/prayer" element={<PrayerPage />} />
      <Route path="/hadith" element={<HadithPage />} />
      <Route path="/names" element={<NamesPage />} />
      <Route path="/calendar" element={<CalendarPage />} />
      <Route path="/library" element={<LibraryPage />} />
      <Route path="/quiz" element={<QuizPage />} />
      <Route path="/chat" element={<ChatPage />} />
      <Route path="/contact" element={<ContactPage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
